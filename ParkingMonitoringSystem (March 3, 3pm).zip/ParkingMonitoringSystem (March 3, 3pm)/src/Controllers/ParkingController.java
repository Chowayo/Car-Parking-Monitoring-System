package Controllers;

import Database.DBConnection;
import Models.Parking;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.ArrayList;
import java.sql.ResultSet;

public class ParkingController {
    
    public void register(Parking park){ 
        
        String query = "UPDATE main_parking SET plate = ?, vehicle = ?, price = ?, time_in = CURRENT_TIMESTAMP, status = 'occupied' WHERE slot = ?";
        
        try (Connection conn = DBConnection.getConnection();
         PreparedStatement ps = conn.prepareStatement(query)){
            
            ps.setString(1, park.getPlate());
            ps.setString(2, park.getVehicle());
            ps.setInt(3, park.getPrice());
            ps.setString(4, park.getSlot());
            
            
            ps.executeUpdate();
            
        
        } catch (SQLException e){
            e.printStackTrace(); //Output if the value is not inserted in the table or try had an error
        }  
    }
    
    public void checkout(String slotname){
        String sql = "UPDATE main_parking SET time_out = CURRENT_TIMESTAMP WHERE slot = ? AND time_out IS NULL";
        
        try (Connection conn = DBConnection.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)){

            ps.setString(1, slotname);
            
            ps.executeUpdate();
        
        }catch(SQLException e){
            System.err.println("Error Updating data: "+ e.getMessage());
            e.printStackTrace();  
        }
    
    }
    
    public void transfer(String slotname){
        String sql = "INSERT INTO log_parking (plate, vehicle, price, slot, time_in, time_out) SELECT plate, vehicle, price, slot, time_in, time_out FROM main_parking WHERE slot = ? AND time_out IS NOT NULL";
        
        try (Connection conn = DBConnection.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)){

            ps.setString(1, slotname);
            
            ps.executeUpdate();
        
        }catch(SQLException e){
            e.printStackTrace();  
        }
    }
    
    
    public void reset(String slotname){
        String sql = "UPDATE main_parking SET plate = 'empty', vehicle = 'empty', price = 0, time_in = NULL, time_out = NULL, status = 'available' WHERE slot = ? AND status = 'occupied'";
        
        try (Connection conn = DBConnection.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)){

            ps.setString(1, slotname);
            
            ps.executeUpdate();
        
        }catch(SQLException e){
            e.printStackTrace();  
        }
    
    }
    
    // Method to get the latest checkout data for the receipt
    public String[] getReceiptData(String slotName) {
        // Create an array to hold our 4 pieces of data: Plate, Time In, Time Out, Price
        String[] data = new String[4]; 
        
        try {
            // 1. Connect to database
            java.sql.Connection conn = Database.DBConnection.getConnection();
            
            // 2. Query the log_parking table. 
            // 'ORDER BY id DESC LIMIT 1' guarantees we get the exact car that JUST checked out!
            String sql = "SELECT plate, time_in, time_out, price FROM log_parking WHERE slot = ? ORDER BY id DESC LIMIT 1";
            
            java.sql.PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, slotName);
            
            java.sql.ResultSet rs = pst.executeQuery();
            
            // 3. If we find the record, save the data into our array
            if (rs.next()) {
                data[0] = rs.getString("plate");
                data[1] = rs.getString("time_in");
                data[2] = rs.getString("time_out");
                data[3] = String.valueOf(rs.getDouble("price"));
            }
            
            // Clean up
            rs.close();
            pst.close();
            
        } catch (Exception e) {
            System.out.println("Error fetching receipt data: " + e.getMessage());
        }
        
        return data; // Send the data back to the dashboard!
    }
    
    public List<Parking> select(){
        List <Parking> parked = new ArrayList<Parking>();
        
        String sql = "Select status from main_parking";
        
        try (Connection conn = DBConnection.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)){
            
            ResultSet rs = ps.executeQuery();
            
            while(rs.next()){
                Parking park = new Parking();
                park.setStatus(rs.getString("status"));
                
                
                parked.add(park);
            }

        }catch(SQLException e){
            System.err.println("Error fetching data: "+ e.getMessage());
            e.printStackTrace();  
        }
        return parked;
    }
    
    
    
}
