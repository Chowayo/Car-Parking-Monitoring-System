
package view.dashboardPanels;

import Controllers.ParkingController;
import Models.Parking;
import java.util.List;
import view.LoginFrame;

public class HomePanel extends javax.swing.JPanel {

    public static int occu_car, occu_motor, occu_pwd, avail_car, avail_motor, avail_pwd, profit;
    public HomePanel() {
        initComponents();
        welcome.setText("Welcome Back, Employee "+LoginFrame.firstname);
        counters();
        
        

    }
    

    public void counters(){
        ParkingController pc = new ParkingController();
        List<Parking> park = pc.select();
              
        int counter = 0;
        int occuCar=0, occuMotor=0, occuPwd=0;
        int availCar = 36, availMotor = 30, availPwd = 4;

        for(Parking parked: park){
            String parked_status = parked.getStatus();
            if(parked_status.equals("occupied") && counter <= 35){
                availCar--;
                occuCar++;  
            }
            if(parked_status.equals("occupied") && counter >= 36 && counter <=65){
                availMotor--;
                occuMotor++;
            }
            if(parked_status.equals("occupied") && counter >= 66){
                availPwd--;
                occuPwd++;    
            }
            counter++;
        }
        //System.out.println(counter);
        this.occu_car = occuCar;
        this.occu_motor = occuMotor;
        this.occu_pwd = occuPwd;
        this.avail_car = availCar;
        this.avail_motor = availMotor;
        this.avail_pwd = availPwd;
        this.profit = pc.day_profit();
        
        revenue.setText(Integer.toString(this.profit));   
        occupiedCar.setText(Integer.toString(this.occu_car));
        occupiedMotor.setText(Integer.toString(this.occu_motor));
        occupiedPwd.setText(Integer.toString(this.occu_pwd));
        availableCar.setText(Integer.toString(this.avail_car));
        availableMotor.setText(Integer.toString(this.avail_motor));
        availablePwd.setText(Integer.toString(this.avail_pwd));
    }
    
    public void loadEmployeeData(String employeeID) {
        Controllers.UserController uc = new Controllers.UserController();
        String fullName = uc.getFullName(employeeID);
        
        fullNameTxt.setText(fullName); 
    }
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        welcome = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jPanel9 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        pwd = new javax.swing.JLabel();
        motor = new javax.swing.JLabel();
        car = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        occupiedCar = new javax.swing.JLabel();
        occupiedMotor = new javax.swing.JLabel();
        occupiedPwd = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        availableMotor = new javax.swing.JLabel();
        availableCar = new javax.swing.JLabel();
        availablePwd = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        revenue = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        fullNameTxt = new javax.swing.JLabel();
        profileIcon = new javax.swing.JLabel();
        refresh = new javax.swing.JButton();

        jLabel1.setText("Home");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(161, 161, 161)
                .addComponent(jLabel1)
                .addContainerGap(206, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(141, 141, 141)
                .addComponent(jLabel1)
                .addContainerGap(143, Short.MAX_VALUE))
        );

        setBackground(new java.awt.Color(240, 240, 240));
        setPreferredSize(new java.awt.Dimension(1044, 766));

        jPanel2.setBackground(new java.awt.Color(255, 81, 0));
        jPanel2.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 4, 4, new java.awt.Color(220, 220, 220)));

        welcome.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        welcome.setForeground(new java.awt.Color(255, 255, 255));
        welcome.setText("Welcome Back, Administrator!");
        welcome.setMaximumSize(new java.awt.Dimension(500, 30));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Here's what's happening with your parking facility today.");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addComponent(welcome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addComponent(welcome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel3)
                .addContainerGap(52, Short.MAX_VALUE))
        );

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setOpaque(false);
        jPanel3.setLayout(new java.awt.GridLayout(2, 2, 20, 20));

        jPanel9.setBackground(new java.awt.Color(255, 255, 255));
        jPanel9.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 4, 4, new java.awt.Color(220, 220, 220)));

        jLabel4.setBackground(new java.awt.Color(255, 255, 255));
        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(102, 102, 102));
        jLabel4.setText("TOTAL SPOTS");
        jLabel4.setVerticalAlignment(javax.swing.SwingConstants.TOP);

        pwd.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        pwd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/pwdIcon.png"))); // NOI18N
        pwd.setText("4");
        pwd.setIconTextGap(20);

        motor.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        motor.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/bigMotorIcon.png"))); // NOI18N
        motor.setText("30");
        motor.setIconTextGap(20);

        car.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        car.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/carParkIcon.png"))); // NOI18N
        car.setText("36");
        car.setIconTextGap(20);

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/orangeCar.png"))); // NOI18N

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(motor)
                            .addComponent(pwd)
                            .addComponent(jLabel4))
                        .addContainerGap(572, Short.MAX_VALUE))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addComponent(car)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel2)
                        .addGap(30, 30, 30))))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(car)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(motor)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(pwd)
                .addGap(16, 16, 16))
        );

        jPanel3.add(jPanel9);

        jPanel10.setBackground(new java.awt.Color(255, 255, 255));
        jPanel10.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 4, 4, new java.awt.Color(220, 220, 220)));

        jLabel9.setBackground(new java.awt.Color(255, 255, 255));
        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(102, 102, 102));
        jLabel9.setText("OCCUPIED");

        occupiedCar.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        occupiedCar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/carParkIcon.png"))); // NOI18N
        occupiedCar.setText("0");
        occupiedCar.setIconTextGap(20);

        occupiedMotor.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        occupiedMotor.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/bigMotorIcon.png"))); // NOI18N
        occupiedMotor.setText("0");
        occupiedMotor.setIconTextGap(20);

        occupiedPwd.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        occupiedPwd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/pwdIcon.png"))); // NOI18N
        occupiedPwd.setText("0");
        occupiedPwd.setIconTextGap(20);

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/orangePerson.png"))); // NOI18N

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(occupiedPwd)
                            .addComponent(jLabel9))
                        .addContainerGap(596, Short.MAX_VALUE))
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(occupiedMotor)
                            .addComponent(occupiedCar))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel5)
                        .addGap(30, 30, 30))))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel9)
                .addGap(2, 2, 2)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addComponent(occupiedCar)
                        .addGap(12, 12, 12)
                        .addComponent(occupiedMotor))
                    .addComponent(jLabel5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(occupiedPwd)
                .addContainerGap(17, Short.MAX_VALUE))
        );

        jPanel3.add(jPanel10);

        jPanel7.setBackground(new java.awt.Color(255, 255, 255));
        jPanel7.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 4, 4, new java.awt.Color(220, 220, 220)));

        jLabel8.setBackground(new java.awt.Color(255, 255, 255));
        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(102, 102, 102));
        jLabel8.setText("AVAILABLE");

        availableMotor.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        availableMotor.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/bigMotorIcon.png"))); // NOI18N
        availableMotor.setText("00");
        availableMotor.setIconTextGap(20);

        availableCar.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        availableCar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/carParkIcon.png"))); // NOI18N
        availableCar.setText("36");
        availableCar.setIconTextGap(20);

        availablePwd.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        availablePwd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/pwdIcon.png"))); // NOI18N
        availablePwd.setText("4");
        availablePwd.setIconTextGap(20);

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/orangeAvail.png"))); // NOI18N

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(availablePwd)
                            .addComponent(jLabel8))
                        .addContainerGap(596, Short.MAX_VALUE))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(availableMotor)
                            .addComponent(availableCar))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel7)
                        .addGap(30, 30, 30))))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel8)
                .addGap(4, 4, 4)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(availableCar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(availableMotor))
                    .addComponent(jLabel7))
                .addGap(12, 12, 12)
                .addComponent(availablePwd)
                .addContainerGap(15, Short.MAX_VALUE))
        );

        jPanel3.add(jPanel7);

        jPanel8.setBackground(new java.awt.Color(255, 255, 255));
        jPanel8.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 4, 4, new java.awt.Color(220, 220, 220)));

        jLabel10.setBackground(new java.awt.Color(255, 255, 255));
        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(102, 102, 102));
        jLabel10.setText("REVENUE TODAY");

        revenue.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        revenue.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/pesoIcon.png"))); // NOI18N
        revenue.setText("0");
        revenue.setIconTextGap(20);

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/orangePeso.png"))); // NOI18N

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addComponent(jLabel10)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addComponent(revenue)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 488, Short.MAX_VALUE)
                        .addComponent(jLabel6)
                        .addGap(30, 30, 30))))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel10)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGap(31, 31, 31)
                        .addComponent(revenue))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel6)))
                .addContainerGap(132, Short.MAX_VALUE))
        );

        jPanel3.add(jPanel8);

        jPanel4.setBackground(new java.awt.Color(235, 235, 235));
        jPanel4.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(204, 204, 204)));

        fullNameTxt.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        fullNameTxt.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        fullNameTxt.setText("Full Name");

        profileIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/orangeCircle.png"))); // NOI18N
        profileIcon.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        profileIcon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                profileIconMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(1358, 1358, 1358)
                .addComponent(fullNameTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(profileIcon)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(profileIcon, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 88, Short.MAX_VALUE)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addComponent(fullNameTxt)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        refresh.setBackground(new java.awt.Color(14, 22, 40));
        refresh.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        refresh.setForeground(new java.awt.Color(255, 255, 255));
        refresh.setText("Refresh");
        refresh.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        refresh.addActionListener(this::refreshActionPerformed);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(refresh)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, 1465, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(86, 86, 86))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(43, 43, 43)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addComponent(refresh, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 536, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void profileIconMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_profileIconMouseClicked

        java.awt.Window parentWindow = javax.swing.SwingUtilities.getWindowAncestor(this);
        java.awt.Frame parentFrame = (java.awt.Frame) parentWindow;

        javax.swing.JDialog settingsPopup = new javax.swing.JDialog(parentFrame, "User Profile", true);

        view.dashboardPanels.AccountSettingsPanel settingsPanel = new view.dashboardPanels.AccountSettingsPanel();

        settingsPopup.getContentPane().add(settingsPanel);

        settingsPopup.pack(); 
        settingsPopup.setLocationRelativeTo(parentFrame);
        settingsPopup.setVisible(true);
        
    }//GEN-LAST:event_profileIconMouseClicked

    private void refreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_refreshActionPerformed
        counters();
    }//GEN-LAST:event_refreshActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel availableCar;
    private javax.swing.JLabel availableMotor;
    private javax.swing.JLabel availablePwd;
    private javax.swing.JLabel car;
    private javax.swing.JLabel fullNameTxt;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JLabel motor;
    private javax.swing.JLabel occupiedCar;
    private javax.swing.JLabel occupiedMotor;
    private javax.swing.JLabel occupiedPwd;
    private javax.swing.JLabel profileIcon;
    private javax.swing.JLabel pwd;
    private javax.swing.JButton refresh;
    private javax.swing.JLabel revenue;
    private javax.swing.JLabel welcome;
    // End of variables declaration//GEN-END:variables
}
