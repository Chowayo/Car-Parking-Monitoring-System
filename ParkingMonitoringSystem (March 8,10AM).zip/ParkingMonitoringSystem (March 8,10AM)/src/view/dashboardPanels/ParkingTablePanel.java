
package view.dashboardPanels;

import Controllers.ParkingController;
import Models.Parking;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class ParkingTablePanel extends javax.swing.JPanel {

    public ParkingTablePanel() {
        initComponents();
        
        //Header Font and Colors
        main_table.getTableHeader().setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 14));
        main_table.getTableHeader().setOpaque(false);
        main_table.getTableHeader().setBackground(new java.awt.Color(15, 23, 42));
        main_table.getTableHeader().setForeground(java.awt.Color.WHITE);

        main_table.getColumnModel().getColumn(0).setPreferredWidth(50);
        main_table.getColumnModel().getColumn(5).setPreferredWidth(180);
        //jTable1.getColumnModel().getColumn(6).setPreferredWidth(180);
        loadParked("SELECT id, plate, vehicle, price, slot, time_in, occupant FROM main_parking WHERE status = 'occupied' ");
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        parkingLogsTbl = new javax.swing.JScrollPane();
        main_table = new javax.swing.JTable();
        searchBar = new javax.swing.JTextField();
        refresh = new javax.swing.JButton();
        searchButton = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        main_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Plate Number", "Vehicle", "Price", "Slot", "Occupant", "Time In"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, true, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        main_table.setGridColor(new java.awt.Color(204, 204, 204));
        main_table.setRowHeight(25);
        main_table.setSelectionBackground(new java.awt.Color(251, 81, 0));
        main_table.setSelectionForeground(new java.awt.Color(255, 255, 255));
        main_table.setShowHorizontalLines(true);
        main_table.setShowVerticalLines(true);
        parkingLogsTbl.setViewportView(main_table);

        searchBar.setForeground(new java.awt.Color(153, 153, 153));
        searchBar.setText("Search Plate Number");
        searchBar.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                searchBarFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                searchBarFocusLost(evt);
            }
        });
        searchBar.addActionListener(this::searchBarActionPerformed);

        refresh.setBackground(new java.awt.Color(14, 22, 40));
        refresh.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        refresh.setForeground(new java.awt.Color(255, 255, 255));
        refresh.setText("Refresh");
        refresh.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        refresh.addActionListener(this::refreshActionPerformed);

        searchButton.setBackground(new java.awt.Color(251, 81, 0));
        searchButton.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        searchButton.setForeground(new java.awt.Color(255, 255, 255));
        searchButton.setText("Search");
        searchButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        searchButton.addActionListener(this::searchButtonActionPerformed);

        jLabel1.setBackground(new java.awt.Color(51, 51, 51));
        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setText("Parking Table");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(parkingLogsTbl)
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 488, Short.MAX_VALUE)
                .addComponent(searchBar, javax.swing.GroupLayout.PREFERRED_SIZE, 284, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(searchButton)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(refresh)
                .addGap(50, 50, 50))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel1)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(searchBar, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(searchButton, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(refresh, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(40, 40, 40)
                .addComponent(parkingLogsTbl, javax.swing.GroupLayout.DEFAULT_SIZE, 830, Short.MAX_VALUE)
                .addContainerGap())
        );
    }// </editor-fold>//GEN-END:initComponents

    
    
    public void loadParked(String sql){
        ParkingController parcon = new ParkingController();
        
        List<Parking> parked = parcon.parking_show(sql);
        
        DefaultTableModel DFT = (DefaultTableModel) main_table.getModel();
        DFT.setRowCount(0);
        for(Parking parks: parked){
            int ids = parks.getId();
            String plates = parks.getPlate();
            String vehicles = parks.getVehicle();
            int prices = parks.getPrice();
            String slots = parks.getSlot();
            String occupant = parks.getOccupant();
            String time_ins = parks.getTime_in();
            
            DFT.addRow(new Object[]{ids, plates, vehicles, prices, slots, occupant, time_ins});        
        }

    }
    private void searchBarFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_searchBarFocusGained
        // TODO add your handling code here:
        if (searchBar.getText().equals("Search Plate Number")) {
            searchBar.setText("");
            searchBar.setForeground(new java.awt.Color(0, 0, 0));
        }
    }//GEN-LAST:event_searchBarFocusGained

    private void searchBarFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_searchBarFocusLost
        // TODO add your handling code here:
        if (searchBar.getText().isEmpty()) {
            searchBar.setText("Search Plate Number");
            searchBar.setForeground(new java.awt.Color(153, 153, 153));
        }
    }//GEN-LAST:event_searchBarFocusLost

    private void searchBarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchBarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_searchBarActionPerformed

    private void searchButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchButtonActionPerformed
        String search = searchBar.getText();
        ParkingController pc = new ParkingController();
        List<Parking> parks = pc.plate_check();
        
        

        
        boolean exist = false;
        for(Parking sample: parks){
            if(sample.getPlate().equals(search)){
                exist=true;
            }
        }
        
        if(exist){
            loadParked("SELECT * FROM main_parking WHERE plate LIKE '%"+search+"%'");
        }else{
            JOptionPane.showMessageDialog(this, "Plate Does Not Exist!", "Search Error!", JOptionPane.ERROR_MESSAGE);
        }
        
        
        
        
        
    }//GEN-LAST:event_searchButtonActionPerformed

    private void refreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_refreshActionPerformed
        loadParked("SELECT id, plate, vehicle, price, slot, time_in, occupant FROM main_parking WHERE status = 'occupied' ");
    }//GEN-LAST:event_refreshActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JTable main_table;
    private javax.swing.JScrollPane parkingLogsTbl;
    private javax.swing.JButton refresh;
    private javax.swing.JTextField searchBar;
    private javax.swing.JButton searchButton;
    // End of variables declaration//GEN-END:variables
}
