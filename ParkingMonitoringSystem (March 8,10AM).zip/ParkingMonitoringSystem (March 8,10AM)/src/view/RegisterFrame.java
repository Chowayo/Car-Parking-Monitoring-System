package view;

import Models.Users; 
import Controllers.UserController; 
import javax.swing.JOptionPane;


public class RegisterFrame extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(RegisterFrame.class.getName());


    public RegisterFrame() {
        initComponents();
        
        this.setLocationRelativeTo(null);
    }
        
        public void hideSignInLink() {
        
        alreadyAccount.setVisible(false); 
        signInBtn.setVisible(false);
        
        
    }
    
    


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        lname = new javax.swing.JTextField();
        fname = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        email = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        pass = new javax.swing.JPasswordField();
        Repass = new javax.swing.JPasswordField();
        jLabel8 = new javax.swing.JLabel();
        sign_in = new javax.swing.JButton();
        signInBtn = new javax.swing.JLabel();
        alreadyAccount = new javax.swing.JLabel();
        employeeID = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(14, 22, 40));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Register Employee");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(157, 165, 177));
        jLabel2.setText("First Name");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(157, 165, 177));
        jLabel3.setText("Last Name");

        lname.setForeground(new java.awt.Color(153, 153, 153));
        lname.setText("Last Name");
        lname.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(157, 165, 177)));
        lname.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                lnameFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                lnameFocusLost(evt);
            }
        });

        fname.setForeground(new java.awt.Color(153, 153, 153));
        fname.setText("First Name");
        fname.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(157, 165, 177)));
        fname.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                fnameFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                fnameFocusLost(evt);
            }
        });
        fname.addActionListener(this::fnameActionPerformed);

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(157, 165, 177));
        jLabel4.setText("Employee Email");

        email.setForeground(new java.awt.Color(153, 153, 153));
        email.setText("Email");
        email.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(157, 165, 177)));
        email.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                emailFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                emailFocusLost(evt);
            }
        });
        email.addActionListener(this::emailActionPerformed);

        jLabel7.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(157, 165, 177));
        jLabel7.setText("Password");

        pass.setForeground(new java.awt.Color(14, 22, 40));
        pass.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(157, 165, 177)));
        pass.addActionListener(this::passActionPerformed);

        Repass.setForeground(new java.awt.Color(14, 22, 40));
        Repass.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(157, 165, 177)));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(157, 165, 177));
        jLabel8.setText("Re-enter password");

        sign_in.setBackground(new java.awt.Color(255, 81, 0));
        sign_in.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        sign_in.setForeground(new java.awt.Color(255, 255, 255));
        sign_in.setText("Sign up");
        sign_in.setBorderPainted(false);
        sign_in.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        sign_in.setFocusPainted(false);
        sign_in.addActionListener(this::sign_inActionPerformed);

        signInBtn.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        signInBtn.setForeground(new java.awt.Color(255, 81, 0));
        signInBtn.setText("<html> <u>Sign In</u></html>");
        signInBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        signInBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                signInBtnMouseClicked(evt);
            }
        });

        alreadyAccount.setForeground(new java.awt.Color(157, 165, 177));
        alreadyAccount.setText("Already have an account?");

        employeeID.setForeground(new java.awt.Color(153, 153, 153));
        employeeID.setText("Employee ID");
        employeeID.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                employeeIDFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                employeeIDFocusLost(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(157, 165, 177));
        jLabel6.setText("Employee ID");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addComponent(jLabel1)
                .addGap(95, 95, 95))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(68, 68, 68)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(fname, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel2))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lname, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel3)))
                            .addComponent(sign_in, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(Repass)
                            .addComponent(jLabel8)
                            .addComponent(pass)
                            .addComponent(jLabel7)
                            .addComponent(email)
                            .addComponent(jLabel4)
                            .addComponent(jLabel6)
                            .addComponent(employeeID)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(147, 147, 147)
                        .addComponent(alreadyAccount)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(signInBtn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(68, 68, 68))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lname, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(fname, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(employeeID, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(email, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(pass, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Repass, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(sign_in, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(alreadyAccount)
                    .addComponent(signInBtn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(50, 50, 50))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void fnameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fnameActionPerformed
        
    }//GEN-LAST:event_fnameActionPerformed

    private void signInBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_signInBtnMouseClicked
        // TODO add your handling code here:
        // open the sign in window
        LoginFrame logFrame = new LoginFrame();
        logFrame.setVisible(true);

        // close register window
        this.dispose();
    }//GEN-LAST:event_signInBtnMouseClicked
   
    private void sign_inActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sign_inActionPerformed
        Users user = new Users(); 
        UserController usercon = new UserController();
        
        String checker = usercon.verify(employeeID.getText(), email.getText());
 
        if(! pass.getText().equals("") &&! Repass.getText().equals("") && ! fname.getText().equals("") && ! lname.getText().equals("") && ! email.getText().equals("") && ! employeeID.getText().equals("")){
            if(pass.getText().equals(Repass.getText())){
                if(pass.getText().length() >= 8){
                    if(checker != "Error"){
                        user.setEmployeeID(employeeID.getText());
                        user.setFname(fname.getText()); 
                        user.setLname(lname.getText());
                        user.setEmail(email.getText());
                        
                        // encrypt
                        String password_convert = usercon.encryptPassword(pass.getText());
                        user.setPassword(password_convert);
                        

                        usercon.register(user);
                        JOptionPane.showMessageDialog(this, "Employee Registered!","Registration Success", JOptionPane.INFORMATION_MESSAGE);

                        if (alreadyAccount.isVisible()) {
                   
                        LoginFrame logFrame = new LoginFrame();
                        logFrame.setVisible(true);
                        }

                        this.dispose();
                    }
                    else{
                        JOptionPane.showMessageDialog(this, "Email or EmployeeID already exists!", "Register Error!", JOptionPane.ERROR_MESSAGE);
                    }   
                }
                else{
                    JOptionPane.showMessageDialog(this, "Password must be atleast 8 characters long!", "Register Error!", JOptionPane.ERROR_MESSAGE);
                }
            }
            else{
                JOptionPane.showMessageDialog(this, "Password must be matched!", "Register Error!", JOptionPane.ERROR_MESSAGE);
            }
        }
        else{
            JOptionPane.showMessageDialog(this, "Incomplete Employee Information!", "Register Error!", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_sign_inActionPerformed

    private void emailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_emailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_emailActionPerformed

    private void fnameFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_fnameFocusGained
        // TODO add your handling code here:
        if (fname.getText().equals("First Name")) {
            fname.setText("");
            fname.setForeground(new java.awt.Color(0, 0, 0));
        }
    }//GEN-LAST:event_fnameFocusGained

    private void fnameFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_fnameFocusLost
        // TODO add your handling code here:
        if (fname.getText().isEmpty()) {
            fname.setText("First Name");
            fname.setForeground(new java.awt.Color(153, 153, 153));
        }
    }//GEN-LAST:event_fnameFocusLost

    private void passActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_passActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_passActionPerformed

    private void lnameFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_lnameFocusGained
        // TODO add your handling code here:
        if (lname.getText().equals("Last Name")) {
            lname.setText("");
            lname.setForeground(new java.awt.Color(0, 0, 0));
        }
    }//GEN-LAST:event_lnameFocusGained

    private void lnameFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_lnameFocusLost
        // TODO add your handling code here:
        if (lname.getText().isEmpty()) {
            lname.setText("Last Name");
            lname.setForeground(new java.awt.Color(153, 153, 153));
        }
    }//GEN-LAST:event_lnameFocusLost

    private void employeeIDFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_employeeIDFocusGained
        // TODO add your handling code here:
        if (employeeID.getText().equals("Employee ID")) {
            employeeID.setText("");
            employeeID.setForeground(new java.awt.Color(0, 0, 0));
        }
    }//GEN-LAST:event_employeeIDFocusGained

    private void employeeIDFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_employeeIDFocusLost
        // TODO add your handling code here:
        if (employeeID.getText().isEmpty()) {
            employeeID.setText("Employee ID");
            employeeID.setForeground(new java.awt.Color(153, 153, 153));
        }
    }//GEN-LAST:event_employeeIDFocusLost

    private void emailFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_emailFocusGained
        // TODO add your handling code here:
        if (email.getText().equals("Email")) {
            email.setText("");
            email.setForeground(new java.awt.Color(0, 0, 0));
        }
    }//GEN-LAST:event_emailFocusGained

    private void emailFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_emailFocusLost
        // TODO add your handling code here:
        if (email.getText().isEmpty()) {
            email.setText("Email");
            email.setForeground(new java.awt.Color(153, 153, 153));
        }
    }//GEN-LAST:event_emailFocusLost

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> new RegisterFrame().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPasswordField Repass;
    private javax.swing.JLabel alreadyAccount;
    private javax.swing.JTextField email;
    private javax.swing.JTextField employeeID;
    private javax.swing.JTextField fname;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField lname;
    private javax.swing.JPasswordField pass;
    private javax.swing.JLabel signInBtn;
    private javax.swing.JButton sign_in;
    // End of variables declaration//GEN-END:variables
}
