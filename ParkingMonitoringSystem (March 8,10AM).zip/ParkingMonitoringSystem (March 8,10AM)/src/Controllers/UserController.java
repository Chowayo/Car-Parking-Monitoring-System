package Controllers;
import Database.DBConnection;
import Models.Users;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class UserController {
    
    public void register(Users user){ 
        String query = "INSERT INTO employees(employeeID, first_name, last_name, email, password) values" //User is the table name
                + "(?,?,?,?,?)";
        
        try (Connection conn = DBConnection.getConnection();
         PreparedStatement ps = conn.prepareStatement(query)){
            
            ps.setString(1, user.getEmployeeID());
            ps.setString(2, user.getFname()); 
            ps.setString(3, user.getLname()); 
            ps.setString(4, user.getEmail()); 
            ps.setString(5, user.getPassword()); 
            
            ps.executeUpdate();
            
        
        } catch (SQLException e){
            e.printStackTrace(); //Output if the value is not inserted in the table or try had an error
        }  
    }
    
    
    public String verify(String employeeID, String email){ //NO EMAIL OR EMPLOYEEID repeat
        String sql = "SELECT * FROM employees"; //Is the SQL syntax for system to run 
        String error_counter = "no_error";
        try (Connection conn = DBConnection.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)){
            ResultSet rs = ps.executeQuery(); 
            while(rs.next()){
                    if(employeeID.equals(rs.getString("employeeID")) || email.equals(rs.getString("email"))){
                        error_counter = "Error";
                    }              
            }
        } catch(Exception e){
            e.printStackTrace();    
        }
        return error_counter;
    }
    
    
    
    public Users authenticate(String employeeID, String password, String DB_table){
        String sql = "SELECT * FROM "+DB_table+" WHERE employeeID = ? AND password = ?"; //Is the SQL syntax for system to run 
        
        try (Connection conn = DBConnection.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)){
            
            int converted_employeeID = Integer.parseInt(employeeID);
        
            ps.setInt(1, converted_employeeID); 
            ps.setString(2, password); 
            
            ResultSet rs = ps.executeQuery(); 
            
            
            if(rs.next()){ 
                Users user = new Users();
                user.setEmployeeID(rs.getString("employeeID"));
                user.setPassword(rs.getString("password")); 
                return user; 
            }


        } catch(Exception e){
            e.printStackTrace();
            
        }
        return null; //IMPORTANT IDK WHY
    }
    
    public String getFullName(String employeeID){
        String fullName = "User";
        String sql = "SELECT first_name, last_name FROM employees WHERE employeeID = ?"; 
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            int converted_employeeID = Integer.parseInt(employeeID);
            ps.setInt(1, converted_employeeID); 
            
            ResultSet rs = ps.executeQuery(); 
            
            if(rs.next()){ 
                String fname = rs.getString("first_name");
                String lname = rs.getString("last_name");
                fullName = fname + " " + lname; 
            }
            
        } catch(Exception e){
            System.err.println("Error fetching full name: "+ e.getMessage());
            e.printStackTrace();
        }
        
        return fullName; 
    }
    
    public String convert(String password, String[] encryp, String[] smallLetters){
        int start=0, end=1, a;
        String new_word="";
        for(int i=0; i<password.length(); i++){
            a = 0;
            for(String encry: encryp){
                if(password.substring(start,end).equals(smallLetters[a])){
                    new_word += encry;
                }
                a++; 
            }
            start++;
            end++;
        }
        return new_word;
    }
    
    public List<Users> session(int employeeID, String password, String DB_table){
        Users user = new Users();
        
        List<Users> sessions = new ArrayList<Users>();
        
        String sql = "Select * from "+DB_table+" WHERE employeeID = ? AND password = ?";
        
        try (Connection conn = DBConnection.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)){
            
            ps.setInt(1, employeeID);
            ps.setString(2, password);
            
            try(ResultSet resultset = ps.executeQuery()){
                if(resultset.next()){
                    user.setId(resultset.getInt("id"));
                    user.setEmployeeID(resultset.getString("employeeID"));
                    user.setFname(resultset.getString("first_name"));
                    user.setLname(resultset.getString("last_name"));
                    user.setEmail(resultset.getString("email"));
                    user.setPassword(resultset.getString("password"));                      
                }
                sessions.add(user);
            }
           
        }catch(SQLException e){
            e.printStackTrace();  
        }
        return sessions;
    }
    
    
    //FOR DEMO ONLY 
    public void update(Users user, int userId){
        String sql = "UPDATE employees SET first_name = ?, last_name = ?, email = ?, password = ? WHERE employeeID = ?";
        
        try (Connection conn = DBConnection.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)){
            
            ps.setString(1, user.getFname());
            ps.setString(2, user.getLname());
            ps.setString(3, user.getEmail());
            ps.setString(4, user.getPassword());
            ps.setInt(5, userId);
            
            ps.executeUpdate();
        
        }catch(SQLException e){
            System.err.println("Error Updating data: "+ e.getMessage());
            e.printStackTrace();  
        }
    
    }
    
    public String encryptPassword(String rawPassword) {
        
        String[] small     = {"a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z","0","1","2","3","4","5","6","7","8","9"}; 
        String[] encrypt_1 = {"b","s","a","y","w","x","7","f","n","C","r","B","3","F","D","L","Y","O","c","E","J","d","q","g","t","l","K","e","T","H","M","m","2","S","5","p","1","R","0","A","X","k","V","i","P","h","G","W","4","8","9","6","j","o","U","I","v","Q","z","Z","N","u"};        
        String[] encrypt_2 = {"i","Q","2","m","B","h","t","E","S","x","L","n","0","J","d","7","I","K","v","R","a","N","8","f","k","P","V","3","w","y","c","4","g","M","O","G","o","1","p","z","u","Y","s","b","W","U","T","l","5","H","F","e","A","D","q","j","9","Z","C","X","6","r"};    
        String[] encrypt_3 = {"G","p","8","V","k","y","z","P","2","S","r","f","c","I","0","L","d","X","n","M","w","t","v","O","J","q","A","B","1","u","6","E","4","h","Z","m","H","i","R","g","K","l","Q","N","a","o","x","7","W","U","Y","s","j","3","C","T","e","5","D","F","9","b"};

        String password_convert = this.convert(rawPassword, encrypt_1, small); //Encryptor1
        password_convert = this.convert(password_convert, encrypt_2, encrypt_1); //Encryptor2
        password_convert = this.convert(password_convert, encrypt_3, encrypt_2); //Encryptor3
        
        return password_convert;
    }
    
    public boolean updatePassword(int userId, String newEncryptedPassword) {
        String query = "UPDATE employees SET password = ? WHERE id = ?";
        
        try (java.sql.Connection conn = Database.DBConnection.getConnection();
             java.sql.PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setString(1, newEncryptedPassword);
            pstmt.setInt(2, userId);
            
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
            
        } catch (java.sql.SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public int getUserIdByEmail(String searchEmail) {
        String query = "SELECT id FROM employees WHERE email = ?";
        
        try (java.sql.Connection conn = Database.DBConnection.getConnection(); 
             java.sql.PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setString(1, searchEmail);
            java.sql.ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return rs.getInt("id");
            }
            
        } catch (java.sql.SQLException e) {
            e.printStackTrace();
        }
        return -1; // Returns -1 if the email doesn't exist
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    //ADMIN STUFF STARTS HERE
    
    public int employee_count(){ 
        String sql = "SELECT COUNT(*) FROM employees"; 
        int count = 0;
        try (Connection conn = DBConnection.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)){
            ResultSet rs = ps.executeQuery(); 
            rs.next();
            count = rs.getInt("COUNT(*)");

        } catch(Exception e){
            e.printStackTrace();    
        }
        return count;
    }
    
    
    
    public List<Users> show_employees(String sql){
        List <Users> users = new ArrayList<Users>();
        
        //String sql = "Select * from employees";
        
        try (Connection conn = DBConnection.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)){
            
            ResultSet rs = ps.executeQuery();
            
            while(rs.next()){
                Users user = new Users();
                user.setEmployeeID(rs.getString("employeeID"));
                user.setFname(rs.getString("first_name"));
                user.setLname(rs.getString("last_name"));
                user.setEmail(rs.getString("email"));
                
                users.add(user);
            }
            
        }catch(SQLException e){
            System.err.println("Error fetching data: "+ e.getMessage());
            e.printStackTrace();  
        }
        return users;
    }
    
    
    
    public String[] EmployeeInfo(String employeeID) {
        String[] employee_data = new String[4]; 
        try {
            java.sql.Connection conn = Database.DBConnection.getConnection();
            String sql = "SELECT * FROM employees WHERE employeeID = ?";
            java.sql.PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, employeeID);
            
            java.sql.ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                employee_data[0] = rs.getString("employeeID");
                employee_data[1] = rs.getString("first_name");
                employee_data[2] = rs.getString("last_name");
                employee_data[3] = rs.getString("email");
            }
            
            // Clean up
            rs.close();
            pst.close();
            
        } catch (Exception e) {
            System.out.println("Error fetching receipt data: " + e.getMessage());
        }
        
        return employee_data; // Send the data back to the dashboard!
    }
    
    public List<Users> empId(){
        List <Users> users = new ArrayList<Users>();
        
        String sql = "Select employeeID from employees";
        
        try (Connection conn = DBConnection.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)){
            
            ResultSet rs = ps.executeQuery();
            
            while(rs.next()){
                Users user = new Users();
                user.setEmployeeID(rs.getString("employeeID"));

                users.add(user);
            }
            
        }catch(SQLException e){
            System.err.println("Error fetching data: "+ e.getMessage());
            e.printStackTrace();  
        }
        return users;
    }

    

    public void update_employee(String employeeID, String fname, String lname, String email, String old_employeeID){ 
        
        String query = "UPDATE employees SET employeeID = ?, first_name = ?, last_name = ?, email = ? WHERE employeeID = ?";
        
        try (Connection conn = DBConnection.getConnection();
         PreparedStatement ps = conn.prepareStatement(query)){ 

            ps.setString(1, employeeID);
            ps.setString(2, fname);
            ps.setString(3, lname);           
            ps.setString(4, email);
            ps.setString(5, old_employeeID);
            ps.executeUpdate();
            
        
        } catch (SQLException e){
            e.printStackTrace(); //Output if the value is not inserted in the table or try had an error
        }  
    }
    
    
    public void delete_employee(String employeeID){
        String sql = "DELETE FROM employees WHERE employeeID = ?";
        
        try (Connection conn = DBConnection.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)){

            ps.setString(1, employeeID);
            
            ps.executeUpdate();
        
        }catch(SQLException e){
            System.err.println("Error Updating data: "+ e.getMessage());
            e.printStackTrace();  
        }
    
    }

}

