package Controllers;

import Database.DBConnection;
import Models.Parking;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.ArrayList;
import java.sql.ResultSet;
import javax.swing.table.DefaultTableModel;

public class ParkingController {
    
    public void register(Parking park){ 
        
        String query = "UPDATE main_parking SET plate = ?, vehicle = ?, price = ?, time_in = CURRENT_TIMESTAMP, status = 'occupied', occupant = ? WHERE slot = ?";
        
        try (Connection conn = DBConnection.getConnection();
         PreparedStatement ps = conn.prepareStatement(query)){
            
            ps.setString(1, park.getPlate());
            ps.setString(2, park.getVehicle());
            ps.setInt(3, park.getPrice());
            
            ps.setString(4, park.getOccupant());
            
            ps.setString(5, park.getSlot());
            
            
            
            ps.executeUpdate();
            
        
        } catch (SQLException e){
            e.printStackTrace(); //Output if the value is not inserted in the table or try had an error
        }  
    }
    
    public void extra(String slot, double extra, double price){ 
        
        String query = "UPDATE main_parking SET extra_fee = ?, price = ? WHERE slot = ?";
        
        try (Connection conn = DBConnection.getConnection();
         PreparedStatement ps = conn.prepareStatement(query)){
            
            ps.setDouble(1, extra);
            ps.setDouble(2, price);
            ps.setString(3, slot);

            ps.executeUpdate();
            
        
        } catch (SQLException e){
            e.printStackTrace(); //Output if the value is not inserted in the table or try had an error
        }  
    }
    
    public void pay(String slot, double payment, double keep_change){ 
        
        String query = "UPDATE main_parking SET payment = ?, keep_change = ? WHERE slot = ?";
        
        try (Connection conn = DBConnection.getConnection();
         PreparedStatement ps = conn.prepareStatement(query)){
            
            ps.setDouble(1, payment);
            ps.setDouble(2, keep_change);
            ps.setString(3, slot);

            ps.executeUpdate();
            
        
        } catch (SQLException e){
            e.printStackTrace(); //Output if the value is not inserted in the table or try had an error
        }  
    }
    
    
    
    public boolean verify_plate(String plate){ 
        String sql = "SELECT plate FROM main_parking"; 
        boolean check = true;
        try (Connection conn = DBConnection.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)){
            ResultSet rs = ps.executeQuery(); 
            while(rs.next()){
                    if(plate.equals(rs.getString("plate"))){
                        check = false;
                    }              
            }
        } catch(Exception e){
            e.printStackTrace();    
        }
        return check;
    }
    
    public boolean verify_slot(String newSlot){ 
        String sql = "SELECT status FROM main_parking WHERE slot = ?"; 
        boolean check = true;
        try (Connection conn = DBConnection.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)){
            ps.setString(1, newSlot);
            ResultSet rs = ps.executeQuery();
            rs.next();
            
            if(rs.getString("status").equals("occupied")){
                check = false;
            }
            

        } catch(Exception e){
            e.printStackTrace();    
        }
        return check;
    }
    
    public int day_check(String Slot){ 
        String sql = "SELECT DATEDIFF(time_out, time_in) AS day_gap FROM main_parking WHERE slot = ?;";
        int gap=0;
        try (Connection conn = DBConnection.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)){
            ps.setString(1, Slot);
            ResultSet rs = ps.executeQuery();
            rs.next();
            
            gap = rs.getInt("day_gap");

        } catch(Exception e){
            e.printStackTrace();    
        }
        return gap;
    }
    
    
    
        
        
    
    public void checkout(String slotname){
        String sql = "UPDATE main_parking SET time_out = CURRENT_TIMESTAMP WHERE slot = ? AND time_out IS NULL";
        
        try (Connection conn = DBConnection.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)){

            ps.setString(1, slotname);
            
            ps.executeUpdate();
        
        }catch(SQLException e){
            System.err.println("Error Updating data: "+ e.getMessage());
            e.printStackTrace();  
        }
    
    }
    
    public void transfer(String slotname){
        String sql = "INSERT INTO log_parking (plate, vehicle, price, extra_fee, slot, occupant, time_in, time_out, payment, keep_change) SELECT plate, vehicle, price, extra_fee, slot, occupant, time_in, time_out, payment, keep_change FROM main_parking WHERE slot = ? AND time_out IS NOT NULL";
        
        try (Connection conn = DBConnection.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)){

            ps.setString(1, slotname);
            
            ps.executeUpdate();
        
        }catch(SQLException e){
            e.printStackTrace();  
        }
    }
    
    
    public void reset(String slotname){
        String sql = "UPDATE main_parking SET plate = 'empty', vehicle = 'empty', price = 0, extra_fee = 0, time_in = NULL, time_out = NULL, status = 'available', payment = 0, keep_change = 0, occupant = 'empty' WHERE slot = ? AND status = 'occupied'";
        
        try (Connection conn = DBConnection.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)){

            ps.setString(1, slotname);
            
            ps.executeUpdate();
        
        }catch(SQLException e){
            e.printStackTrace();  
        }
    
    }
    
    
    
    // Method to get the latest checkout data for the receipt (GETS FROM THE LATEST id on PARKING LOGS)
    public String[] getReceiptData(String slotName) {
        // Create an array to hold our 4 pieces of data: Plate, Time In, Time Out, Price
        String[] data = new String[8]; 
        
        try {
            // 1. Connect to database
            java.sql.Connection conn = Database.DBConnection.getConnection();
            String sql = "SELECT plate, time_in, time_out, price, id, slot, occupant, vehicle FROM log_parking WHERE slot = ? ORDER BY id DESC LIMIT 1";
            java.sql.PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, slotName);
            
            java.sql.ResultSet rs = pst.executeQuery();
            
            // 3. If we find the record, save the data into our array
            if (rs.next()) {
                data[0] = rs.getString("plate");
                data[1] = rs.getString("time_in");
                data[2] = rs.getString("time_out");
                data[3] = String.valueOf(rs.getDouble("price"));
                data[4] = String.valueOf(rs.getInt("id"));
                data[5] = rs.getString("slot");
                data[6] = rs.getString("vehicle");
                data[7] = rs.getString("occupant");
            }
            
            // Clean up
            rs.close();
            pst.close();
            
        } catch (Exception e) {
            System.out.println("Error fetching receipt data: " + e.getMessage());
        }
        
        return data; // Send the data back to the dashboard!
    }
    
    
    
    
    public String[] getMainData(String slotName) {
        String[] main_data = new String[8]; 
        
        try {
            java.sql.Connection conn = Database.DBConnection.getConnection();
            String sql = "SELECT plate, time_in, time_out, price, id, slot, vehicle, occupant FROM main_parking WHERE slot = ?";
            java.sql.PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, slotName);
            
            java.sql.ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                main_data[0] = rs.getString("plate");
                main_data[1] = rs.getString("time_in");
                main_data[2] = rs.getString("time_out");
                main_data[3] = String.valueOf(rs.getDouble("price"));
                main_data[4] = String.valueOf(rs.getInt("id"));
                main_data[5] = rs.getString("slot");
                main_data[6] = rs.getString("vehicle");
                main_data[7] = rs.getString("occupant");
            }
            
            // Clean up
            rs.close();
            pst.close();
            
        } catch (Exception e) {
            System.out.println("Error fetching receipt data: " + e.getMessage());
        }
        
        return main_data; // Send the data back to the dashboard!
    }
    
    
    
    public List<Parking> select(){
        List <Parking> parked = new ArrayList<Parking>();
        
        String sql = "Select status from main_parking";
        
        try (Connection conn = DBConnection.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)){
            
            ResultSet rs = ps.executeQuery();
            
            while(rs.next()){
                Parking park = new Parking();
                park.setStatus(rs.getString("status"));
                
                
                parked.add(park);
            }

        }catch(SQLException e){
            System.err.println("Error fetching data: "+ e.getMessage());
            e.printStackTrace();  
        }
        return parked;
    }
    
    
    
    
    
    public List<Parking> parking_show(){
        List <Parking> parked = new ArrayList<Parking>();
        
        String sql = "SELECT id, plate, vehicle, price, slot, time_in, occupant FROM main_parking WHERE status = 'occupied' ";
        
        try (Connection conn = DBConnection.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)){
            
            ResultSet rs = ps.executeQuery();
            
            while(rs.next()){
                Parking park = new Parking();
                park.setId(rs.getInt("id"));
                park.setPlate(rs.getString("plate"));
                park.setVehicle(rs.getString("vehicle"));
                park.setPrice(rs.getInt("price"));
                park.setSlot(rs.getString("slot"));
                park.setOccupant(rs.getString("occupant"));
                park.setTime_in(rs.getString("time_in"));
                
                parked.add(park);
            }
            
        }catch(SQLException e){
            System.err.println("Error fetching data: "+ e.getMessage());
            e.printStackTrace();  
        }
        return parked;
    }
    
    
    
    
    
    public List<Parking> parking_logs(){
        List <Parking> parked = new ArrayList<Parking>();
        
        String sql = "SELECT * FROM log_parking";
        
        try (Connection conn = DBConnection.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)){
            
            ResultSet rs = ps.executeQuery();
            
            while(rs.next()){
                Parking park = new Parking();
                park.setId(rs.getInt("id"));
                park.setPlate(rs.getString("plate"));
                park.setVehicle(rs.getString("vehicle"));
                park.setPrice(rs.getInt("price"));
                park.setSlot(rs.getString("slot"));
                park.setOccupant(rs.getString("occupant"));
                park.setTime_in(rs.getString("time_in"));
                park.setTime_out(rs.getString("time_out"));
                
                parked.add(park);
            }
            
        }catch(SQLException e){
            System.err.println("Error fetching data: "+ e.getMessage());
            e.printStackTrace();  
        }
        return parked;
    }
    
    
    
    
    public void relocate(String slotname, String newSlot){
        String sql = "SELECT plate, vehicle, price, time_in, status, occupant FROM main_parking WHERE slot = ?"; 
        
        try (Connection conn = DBConnection.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)){
            ps.setString(1, slotname);
            ResultSet rs = ps.executeQuery();
            String sql_1 = "UPDATE main_parking SET plate= ?, vehicle = ?, price = ?, time_in = ?, status = ?, occupant = ?  WHERE slot = ?";
            rs.next();
            try (Connection connn = DBConnection.getConnection();
             PreparedStatement pss = conn.prepareStatement(sql_1)){
                pss.setString(1, rs.getString("plate"));
                pss.setString(2, rs.getString("vehicle"));
                
                String init = newSlot.substring(0,1);
                double price=0;
                
                if(init.equals("A") || init.equals("B") || init.equals("C")){
                    price = 60.0;
                }else if(init.equals("D") || init.equals("E")){
                    price = 40.0;
                }else if(init.equals("P")){
                    price = 0;
                }

                pss.setDouble   (3, price);
                pss.setString(4, rs.getString("time_in"));
                pss.setString(5, rs.getString("status"));
                pss.setString(6, rs.getString("occupant"));
                
                pss.setString(7, newSlot);
                pss.executeUpdate();

            }catch(SQLException e){
                System.err.println("Error Updating data: "+ e.getMessage());
                e.printStackTrace();  
            }
        }catch(SQLException e){
            System.err.println("Error Showing data: "+ e.getMessage());
            e.printStackTrace();  
        }
        
        
        
    
    }
    
    
    

    
    
    
}
