
package view.dashboardPanels;

import Controllers.ParkingController;
import Models.Parking;
import java.util.List;
import javax.swing.table.DefaultTableModel;

public class ParkingLogsPanel extends javax.swing.JPanel {

    public ParkingLogsPanel() {
        initComponents();

        //Header Font and Colors
        parking_log.getTableHeader().setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 14));
        parking_log.getTableHeader().setOpaque(false);
        parking_log.getTableHeader().setBackground(new java.awt.Color(15, 23, 42));
        parking_log.getTableHeader().setForeground(java.awt.Color.WHITE);

        parking_log.getColumnModel().getColumn(0).setPreferredWidth(50);
        parking_log.getColumnModel().getColumn(5).setPreferredWidth(180);
        parking_log.getColumnModel().getColumn(6).setPreferredWidth(180);
        loadLogs();
        
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        parkingLogsTbl = new javax.swing.JScrollPane();
        parking_log = new javax.swing.JTable();
        searchBar = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        refresh = new javax.swing.JButton();

        setBackground(new java.awt.Color(245, 245, 245));

        parking_log.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Plate Number", "Vehicle", "Price", "Slot", "Time In", "Time Out"
            }
        ));
        parking_log.setGridColor(new java.awt.Color(204, 204, 204));
        parking_log.setRowHeight(25);
        parking_log.setSelectionBackground(new java.awt.Color(251, 81, 0));
        parking_log.setSelectionForeground(new java.awt.Color(255, 255, 255));
        parking_log.setShowHorizontalLines(true);
        parking_log.setShowVerticalLines(true);
        parkingLogsTbl.setViewportView(parking_log);

        searchBar.setForeground(new java.awt.Color(153, 153, 153));
        searchBar.setText("Search Plate Number");
        searchBar.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                searchBarFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                searchBarFocusLost(evt);
            }
        });
        searchBar.addActionListener(this::searchBarActionPerformed);

        jLabel1.setBackground(new java.awt.Color(51, 51, 51));
        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setText("Parking Logs");

        jButton1.setBackground(new java.awt.Color(251, 81, 0));
        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("Search");
        jButton1.addActionListener(this::jButton1ActionPerformed);

        refresh.setBackground(new java.awt.Color(14, 22, 40));
        refresh.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        refresh.setForeground(new java.awt.Color(255, 255, 255));
        refresh.setText("Refresh");
        refresh.addActionListener(this::refreshActionPerformed);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(44, 44, 44)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 496, Short.MAX_VALUE)
                .addComponent(searchBar, javax.swing.GroupLayout.PREFERRED_SIZE, 284, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(refresh)
                .addGap(50, 50, 50))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(parkingLogsTbl)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(searchBar, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(refresh, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(40, 40, 40))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(38, 38, 38)))
                .addComponent(parkingLogsTbl, javax.swing.GroupLayout.PREFERRED_SIZE, 885, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
    }// </editor-fold>//GEN-END:initComponents

    public void loadLogs(){
        ParkingController parcon = new ParkingController();
        
        List<Parking> parked = parcon.parking_logs();
        
        DefaultTableModel DFT = (DefaultTableModel) parking_log.getModel();
        DFT.setRowCount(0);
        for(Parking parks: parked){
            int ids = parks.getId();
            String plates = parks.getPlate();
            String vehicles = parks.getVehicle();
            int prices = parks.getPrice();
            String slots = parks.getSlot();
            String time_ins = parks.getTime_in();
            String time_outs = parks.getTime_out();
            
            DFT.addRow(new Object[]{ids, plates, vehicles, prices, slots,time_ins, time_outs});        
        }

    }
    
    
    private void searchBarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchBarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_searchBarActionPerformed

    private void searchBarFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_searchBarFocusGained
        // TODO add your handling code here:
        if (searchBar.getText().equals("Search Plate Number")) {
            searchBar.setText("");
            searchBar.setForeground(new java.awt.Color(0, 0, 0));
        }
    }//GEN-LAST:event_searchBarFocusGained

    private void searchBarFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_searchBarFocusLost
        // TODO add your handling code here:
        if (searchBar.getText().isEmpty()) {
            searchBar.setText("Search Plate Number");
            searchBar.setForeground(new java.awt.Color(153, 153, 153));
        }
    }//GEN-LAST:event_searchBarFocusLost

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    private void refreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_refreshActionPerformed
         loadLogs();
    }//GEN-LAST:event_refreshActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane parkingLogsTbl;
    private javax.swing.JTable parking_log;
    private javax.swing.JButton refresh;
    private javax.swing.JTextField searchBar;
    // End of variables declaration//GEN-END:variables
}
