
package view;
import Controllers.ParkingController;
import Controllers.UserController;
import Models.Users;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class AdminDashboardFrame extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(AdminDashboardFrame.class.getName());
    
    public static int profit, employee_count;
    



    public AdminDashboardFrame(String employeeId) {
        initComponents();
        loadEmployee();
        welcome.setText("Welcome Back, Admin "+LoginFrame.firstname);
        
        this.setExtendedState(javax.swing.JFrame.MAXIMIZED_BOTH);
        dashboardInfo();
        
        fullNameTxt.setText(LoginFrame.firstname+" "+LoginFrame.lastname);
        
        this.requestFocusInWindow();
        
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        fullNameTxt = new javax.swing.JLabel();
        profileIcon = new javax.swing.JLabel();
        logoutBtn = new javax.swing.JToggleButton();
        jPanel2 = new javax.swing.JPanel();
        welcome = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        revenue = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        employee = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        addEmployee = new javax.swing.JButton();
        refresh = new javax.swing.JButton();
        deleteEmployee = new javax.swing.JButton();
        updateEmployee = new javax.swing.JButton();
        searchBar = new javax.swing.JTextField();
        searchButton = new javax.swing.JButton();
        table = new javax.swing.JScrollPane();
        employeeTable = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel4.setBackground(new java.awt.Color(235, 235, 235));
        jPanel4.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(204, 204, 204)));

        fullNameTxt.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        fullNameTxt.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        fullNameTxt.setText("Full Name");

        profileIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/orangeCircle.png"))); // NOI18N
        profileIcon.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        profileIcon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                profileIconMouseClicked(evt);
            }
        });

        logoutBtn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        logoutBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/blackLogout.png"))); // NOI18N
        logoutBtn.setText("Logout");
        logoutBtn.setBorderPainted(false);
        logoutBtn.setContentAreaFilled(false);
        logoutBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        logoutBtn.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        logoutBtn.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        logoutBtn.setIconTextGap(15);
        logoutBtn.setMargin(new java.awt.Insets(2, 20, 3, 14));
        logoutBtn.addActionListener(this::logoutBtnActionPerformed);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(profileIcon)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(fullNameTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(logoutBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(14, 14, 14))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(profileIcon, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 62, Short.MAX_VALUE)
            .addComponent(fullNameTxt, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(logoutBtn, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jPanel2.setBackground(new java.awt.Color(14, 22, 40));
        jPanel2.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 4, 4, new java.awt.Color(220, 220, 220)));

        welcome.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        welcome.setForeground(new java.awt.Color(255, 255, 255));
        welcome.setText("Welcome Back, Administrator!");
        welcome.setMaximumSize(new java.awt.Dimension(500, 30));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Here's the information about the employees.");

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/641115070_960940203026398_8345294270381116164_n (1).png"))); // NOI18N

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addComponent(welcome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(welcome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel3)
                .addContainerGap(26, Short.MAX_VALUE))
        );

        jPanel3.setLayout(new java.awt.GridLayout(1, 2, 20, 20));

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));

        revenue.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        revenue.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/pesoIcon.png"))); // NOI18N
        revenue.setText("0");
        revenue.setIconTextGap(20);

        jLabel10.setBackground(new java.awt.Color(255, 255, 255));
        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(102, 102, 102));
        jLabel10.setText("REVENUE TODAY");

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/orangePeso.png"))); // NOI18N

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(revenue)
                    .addComponent(jLabel10))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 529, Short.MAX_VALUE)
                .addComponent(jLabel6)
                .addGap(30, 30, 30))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel10)
                        .addGap(31, 31, 31)
                        .addComponent(revenue)))
                .addContainerGap(69, Short.MAX_VALUE))
        );

        jPanel3.add(jPanel5);

        jPanel6.setBackground(new java.awt.Color(255, 255, 255));

        jLabel11.setBackground(new java.awt.Color(255, 255, 255));
        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(102, 102, 102));
        jLabel11.setText("EMPLOYEE COUNT");

        employee.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        employee.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/employeeIcon.png"))); // NOI18N
        employee.setText("0");
        employee.setIconTextGap(20);

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/orangePerson.png"))); // NOI18N

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(employee)
                    .addComponent(jLabel11))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 528, Short.MAX_VALUE)
                .addComponent(jLabel5)
                .addGap(30, 30, 30))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jLabel11)
                        .addGap(31, 31, 31)
                        .addComponent(employee)))
                .addContainerGap(69, Short.MAX_VALUE))
        );

        jPanel3.add(jPanel6);

        addEmployee.setBackground(new java.awt.Color(14, 22, 40));
        addEmployee.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        addEmployee.setForeground(new java.awt.Color(255, 255, 255));
        addEmployee.setText("Add Employee");
        addEmployee.setActionCommand("");
        addEmployee.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        addEmployee.addActionListener(this::addEmployeeActionPerformed);

        refresh.setBackground(new java.awt.Color(255, 81, 0));
        refresh.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        refresh.setForeground(new java.awt.Color(255, 255, 255));
        refresh.setText("Refresh");
        refresh.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        refresh.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        refresh.addActionListener(this::refreshActionPerformed);

        deleteEmployee.setBackground(new java.awt.Color(14, 22, 40));
        deleteEmployee.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        deleteEmployee.setForeground(new java.awt.Color(255, 255, 255));
        deleteEmployee.setText("Delete Employee");
        deleteEmployee.setActionCommand("");
        deleteEmployee.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        deleteEmployee.addActionListener(this::deleteEmployeeActionPerformed);

        updateEmployee.setBackground(new java.awt.Color(14, 22, 40));
        updateEmployee.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        updateEmployee.setForeground(new java.awt.Color(255, 255, 255));
        updateEmployee.setText("Update Employee");
        updateEmployee.setActionCommand("");
        updateEmployee.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        updateEmployee.addActionListener(this::updateEmployeeActionPerformed);

        searchBar.setForeground(new java.awt.Color(153, 153, 153));
        searchBar.setText("Search Employee ID");
        searchBar.setToolTipText("");
        searchBar.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                searchBarFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                searchBarFocusLost(evt);
            }
        });
        searchBar.addActionListener(this::searchBarActionPerformed);

        searchButton.setBackground(new java.awt.Color(251, 81, 0));
        searchButton.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        searchButton.setForeground(new java.awt.Color(255, 255, 255));
        searchButton.setText("Search");
        searchButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                        .addComponent(searchBar, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(searchButton)
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(updateEmployee, javax.swing.GroupLayout.DEFAULT_SIZE, 186, Short.MAX_VALUE)
                            .addComponent(addEmployee, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(refresh, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(deleteEmployee, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(62, 62, 62))))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap(30, Short.MAX_VALUE)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(searchBar, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(searchButton, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(50, 50, 50)
                .addComponent(refresh, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(addEmployee, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(updateEmployee, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(deleteEmployee, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        table.setBackground(new java.awt.Color(255, 255, 255));

        employeeTable.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        employeeTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Employee ID", "First Name", "Last Name", "Email"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        employeeTable.setGridColor(new java.awt.Color(204, 204, 204));
        employeeTable.setRowHeight(25);
        employeeTable.setSelectionBackground(new java.awt.Color(251, 81, 0));
        employeeTable.setSelectionForeground(new java.awt.Color(255, 255, 255));
        employeeTable.setShowHorizontalLines(true);
        employeeTable.setShowVerticalLines(true);
        table.setViewportView(employeeTable);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                        .addComponent(table)
                        .addGap(30, 30, 30)
                        .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(44, 44, 44))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(50, 50, 50)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(table, javax.swing.GroupLayout.PREFERRED_SIZE, 453, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(50, 50, 50))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public void dashboardInfo(){
        ParkingController pc = new ParkingController();
        UserController usercon = new UserController();
        this.profit = pc.day_profit();
        revenue.setText(Integer.toString(profit)); 
        
        this.employee_count = usercon.employee_count();
        employee.setText(Integer.toString(employee_count));
    }
    
    public void loadEmployee(){
        UserController usercon = new UserController();
        
        List<Users> users = usercon.show_employees();
        
        DefaultTableModel DFT = (DefaultTableModel) employeeTable.getModel();
        DFT.setRowCount(0);
        for(Users person: users){
            String employeeID = person.getEmployeeID();
            String fname = person.getFname();
            String lname = person.getLname();
            String email = person.getEmail();
            
            DFT.addRow(new Object[]{employeeID, fname, lname, email});        
        }

    }
    
    private void profileIconMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_profileIconMouseClicked

        java.awt.Window parentWindow = javax.swing.SwingUtilities.getWindowAncestor(this);
        java.awt.Frame parentFrame = (java.awt.Frame) parentWindow;
        javax.swing.JDialog settingsPopup = new javax.swing.JDialog(parentFrame, "User Profile", true);
        view.dashboardPanels.AccountSettingsPanel settingsPanel = new view.dashboardPanels.AccountSettingsPanel();
        settingsPopup.getContentPane().add(settingsPanel);
        settingsPopup.pack();
        settingsPopup.setLocationRelativeTo(parentFrame);
        settingsPopup.setVisible(true);
    }//GEN-LAST:event_profileIconMouseClicked

    private void addEmployeeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addEmployeeActionPerformed
        // TODO add your handling code here:
        RegisterFrame register = new RegisterFrame();
        register.setVisible(true);
        register.hideSignInLink(); 
        register.setVisible(true);
    }//GEN-LAST:event_addEmployeeActionPerformed

    private void updateEmployeeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateEmployeeActionPerformed
        
        String inputId = javax.swing.JOptionPane.showInputDialog(this, 
            "Enter Employee ID to update:", 
            "Search Employee", 
            javax.swing.JOptionPane.QUESTION_MESSAGE);

        if (inputId == null) {
            return;
        }

        if (inputId.trim().isEmpty()) {
            javax.swing.JOptionPane.showMessageDialog(this, 
                "Employee ID cannot be empty!", 
                "Error", 
                javax.swing.JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        UserController usercon = new UserController();
        List<Users> users = usercon.empId();
        
        boolean exist = false;
        for(Users sample: users){
            if(sample.getEmployeeID().equals(inputId)){
                exist=true;
            }
        }
        
        if(exist){
            javax.swing.JDialog updatePopup = new javax.swing.JDialog(this, "Update Employee - " + inputId, true);

            view.dashboardPanels.UpdateEmployees updatePanel = new view.dashboardPanels.UpdateEmployees(inputId);

            updatePopup.getContentPane().add(updatePanel);

            updatePopup.pack();
            updatePopup.setLocationRelativeTo(this); 
            updatePopup.setVisible(true);
        }else{
            JOptionPane.showMessageDialog(this, "Employee ID Does Not Exist!", "Update Error!", JOptionPane.ERROR_MESSAGE);
        
        }
        


    }//GEN-LAST:event_updateEmployeeActionPerformed

    private void refreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_refreshActionPerformed
        loadEmployee();
        dashboardInfo();
    }//GEN-LAST:event_refreshActionPerformed

    private void deleteEmployeeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteEmployeeActionPerformed
        // TODO add your handling code here:
        String inputId = javax.swing.JOptionPane.showInputDialog(this, 
            "Enter Employee ID to delete:", 
            "Delete Employee", 
            javax.swing.JOptionPane.QUESTION_MESSAGE);

        if (inputId == null) {
            return; // Stop the code completely
        }

        if (inputId.trim().isEmpty()) {
            javax.swing.JOptionPane.showMessageDialog(this, 
                "Employee ID cannot be empty!", 
                "Error", 
                javax.swing.JOptionPane.ERROR_MESSAGE);
            return; 
        }
        
        UserController usercon = new UserController();
        List<Users> users = usercon.empId();
        boolean exist = false;
        for(Users sample: users){
            if(sample.getEmployeeID().equals(inputId)){
                exist=true;
            }
        }
        
        if(exist){
            // Are you sure?
            int confirm = javax.swing.JOptionPane.showConfirmDialog(this, 
                "Are you absolutely sure you want to permanently delete Employee ID: " + inputId + "?\nThis action cannot be undone.", 
                "Confirm Deletion", 
                javax.swing.JOptionPane.YES_NO_OPTION, 
                javax.swing.JOptionPane.WARNING_MESSAGE);

            if (confirm == javax.swing.JOptionPane.YES_OPTION) {

                usercon.delete_employee(inputId);

                javax.swing.JOptionPane.showMessageDialog(this, "Employee ID has been deleted");
            }   
        }else{
            JOptionPane.showMessageDialog(this, "Employee ID Does Not Exist!", "Delete Error!", JOptionPane.ERROR_MESSAGE);
        }
        


    }//GEN-LAST:event_deleteEmployeeActionPerformed

    private void searchBarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchBarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_searchBarActionPerformed

    private void searchBarFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_searchBarFocusGained
        // TODO add your handling code here:
        if (searchBar.getText().equals("Search Employee ID")) {
            searchBar.setText("");
            searchBar.setForeground(new java.awt.Color(0, 0, 0));
        }
    }//GEN-LAST:event_searchBarFocusGained

    private void searchBarFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_searchBarFocusLost
        // TODO add your handling code here:
        if (searchBar.getText().isEmpty()) {
            searchBar.setText("Search Employee ID");
            searchBar.setForeground(new java.awt.Color(153, 153, 153));
        }
    }//GEN-LAST:event_searchBarFocusLost

    private void logoutBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logoutBtnActionPerformed
        // TODO add your handling code here:
        // Ask for confirmation
        int confirm = javax.swing.JOptionPane.showConfirmDialog(this,
            "Are you sure you want to logout?", "Logout",
            javax.swing.JOptionPane.YES_NO_OPTION);

        if (confirm == javax.swing.JOptionPane.YES_OPTION) {
            // Open the Login Frame
            new LoginFrame().setVisible(true);

            // Close the current Dashboard
            this.dispose();
        } else {
            // Deselect the button if they cancel
            logoutBtn.setSelected(false);
        }
    }//GEN-LAST:event_logoutBtnActionPerformed

    
    public static void main(String args[]) {
        
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        
        java.awt.EventQueue.invokeLater(() -> new AdminDashboardFrame("0").setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addEmployee;
    private javax.swing.JButton deleteEmployee;
    private javax.swing.JLabel employee;
    private javax.swing.JTable employeeTable;
    private javax.swing.JLabel fullNameTxt;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JToggleButton logoutBtn;
    private javax.swing.JLabel profileIcon;
    private javax.swing.JButton refresh;
    private javax.swing.JLabel revenue;
    private javax.swing.JTextField searchBar;
    private javax.swing.JButton searchButton;
    private javax.swing.JScrollPane table;
    private javax.swing.JButton updateEmployee;
    private javax.swing.JLabel welcome;
    // End of variables declaration//GEN-END:variables
}
