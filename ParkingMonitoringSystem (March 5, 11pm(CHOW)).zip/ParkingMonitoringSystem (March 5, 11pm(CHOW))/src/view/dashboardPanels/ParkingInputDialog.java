package view.dashboardPanels;
import Controllers.ParkingController;
import Models.Parking;
import javax.swing.JOptionPane;



public class ParkingInputDialog extends javax.swing.JDialog {
    
    private javax.swing.JPanel targetSlot;
    public String dumm_slotname, slot;

    public void setTargetSlot(javax.swing.JPanel slot) {
        this.targetSlot = slot;
    }
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(ParkingInputDialog.class.getName());

    
    public ParkingInputDialog(java.awt.Frame parent, boolean modal, String slotName) {
        super(parent, modal);
        initComponents();
        main_label.setText("INPUT PARKING INFORMATION ON "+slotName);
        
        this.dumm_slotname = slotName.substring(0,1);
        this.slot = slotName;
        
        String slot_char = slotName.substring(0,1);
        if(slot_char.equals("D") || slot_char.equals("E")){
            vehicleType.removeItem("Sedan");
            vehicleType.removeItem("SUV");
            vehicleType.removeItem("Truck");
            vehicleType.removeItem("Electric Vehicle");
            vehicleType.addItem("Senior");
        
        }else if(slot_char.equals("A") || slot_char.equals("B") || slot_char.equals("C") ){
            vehicleType.removeItem("Motorcycle");
            vehicleType.addItem("Senior");
        }
        
        if (slotName.startsWith("PWD")) {
            
            // Auto-select the PWD radio button
            pwdRadioBtn.setSelected(true); 
            
            // Hide all three radio buttons
            regularRadioBtn.setVisible(false);
            seniorRadioBtn.setVisible(false); 
            pwdRadioBtn.setVisible(false);
            
        } else {
            // If it is a normal slot, make sure Regular is selected by default and everything is visible
            regularRadioBtn.setSelected(true);
            regularRadioBtn.setVisible(true);
            seniorRadioBtn.setVisible(true);
            pwdRadioBtn.setVisible(true);
        }
     
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        main_label = new javax.swing.JLabel();
        plateNum = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        vehicleType = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        submitBtn = new javax.swing.JButton();
        cancelBtn = new javax.swing.JButton();
        regularRadioBtn = new javax.swing.JRadioButton();
        seniorRadioBtn = new javax.swing.JRadioButton();
        pwdRadioBtn = new javax.swing.JRadioButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        main_label.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        main_label.setForeground(new java.awt.Color(15, 23, 42));
        main_label.setText("INPUT PARKING INFORMATION");

        plateNum.setPreferredSize(new java.awt.Dimension(64, 30));
        plateNum.addActionListener(this::plateNumActionPerformed);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel2.setText("Plate Number :");

        vehicleType.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Sedan", "SUV", "Motorcycle", "Electric Vehicle", "Truck", "Others" }));
        vehicleType.setPreferredSize(new java.awt.Dimension(113, 30));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel3.setText("Vehicle Type :");

        submitBtn.setBackground(new java.awt.Color(255, 102, 0));
        submitBtn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        submitBtn.setForeground(new java.awt.Color(255, 255, 255));
        submitBtn.setText("Submit");
        submitBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        submitBtn.setFocusPainted(false);
        submitBtn.addActionListener(this::submitBtnActionPerformed);

        cancelBtn.setBackground(new java.awt.Color(14, 22, 40));
        cancelBtn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        cancelBtn.setForeground(new java.awt.Color(255, 255, 255));
        cancelBtn.setText("Cancel");
        cancelBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        cancelBtn.addActionListener(this::cancelBtnActionPerformed);

        buttonGroup1.add(regularRadioBtn);
        regularRadioBtn.setText("Regular");

        buttonGroup1.add(seniorRadioBtn);
        seniorRadioBtn.setText("Senior Citizen");

        buttonGroup1.add(pwdRadioBtn);
        pwdRadioBtn.setText("PWD");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(69, 69, 69)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(main_label)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addComponent(submitBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(cancelBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel2)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(regularRadioBtn)
                                    .addComponent(jLabel3)))
                            .addGap(30, 30, 30)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addComponent(seniorRadioBtn)
                                    .addGap(30, 30, 30)
                                    .addComponent(pwdRadioBtn)
                                    .addGap(41, 41, 41))
                                .addComponent(vehicleType, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(plateNum, javax.swing.GroupLayout.PREFERRED_SIZE, 216, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(89, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addComponent(main_label)
                .addGap(46, 46, 46)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(plateNum, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addGap(30, 30, 30)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(vehicleType, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addGap(30, 30, 30)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(regularRadioBtn)
                    .addComponent(seniorRadioBtn)
                    .addComponent(pwdRadioBtn))
                .addGap(30, 30, 30)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(submitBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cancelBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(69, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void plateNumActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_plateNumActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_plateNumActionPerformed

    private void submitBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitBtnActionPerformed
        // TODO add your handling code here:
        
        
        
        
        if (targetSlot != null) {
            // Turn slot red

            ParkingLayoutPanel pl = new ParkingLayoutPanel();

            //Submit information to DB
            
            ParkingController pc = new ParkingController();
            
            boolean checker = pc.verify_plate(plateNum.getText());
            Parking park = new Parking();
            
            //Parking register
            if(! plateNum.getText().equals("")){
                if(checker){
                    int price=0;
                    if(dumm_slotname.equals("A") || dumm_slotname.equals("B") || dumm_slotname.equals("C")){
                        price = 60;
                    }else if(dumm_slotname.equals("D") || dumm_slotname.equals("E")){
                        price = 40;
                    }else if(dumm_slotname.equals("P")){
                        price = 0;
                    }
                    park.setPlate(plateNum.getText());           
                    park.setVehicle(vehicleType.getSelectedItem().toString()); 
                    park.setPrice(price);
                    park.setSlot(slot);
                    pc.register(park); //Submits data
                    targetSlot.setBackground(new java.awt.Color(210, 43, 43)); 
                    targetSlot.revalidate();
                    targetSlot.repaint();
                    JOptionPane.showMessageDialog(this, "Parking registration Successful");
                }else{
                    JOptionPane.showMessageDialog(this, "Invalid plate already in-use!", "Register Error!", JOptionPane.ERROR_MESSAGE);
                }
            }else{
                JOptionPane.showMessageDialog(this, "Invalid plate number!", "Register Error!", JOptionPane.ERROR_MESSAGE);
            }
            // Close
            this.dispose();
       
        }
    }//GEN-LAST:event_submitBtnActionPerformed

    private void cancelBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelBtnActionPerformed
        this.dispose();
    }//GEN-LAST:event_cancelBtnActionPerformed

    
    public static void main(String args[]) {
        
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                
                ParkingInputDialog dialog = new ParkingInputDialog(new javax.swing.JFrame(), true, "dummy");
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JButton cancelBtn;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel main_label;
    private javax.swing.JTextField plateNum;
    private javax.swing.JRadioButton pwdRadioBtn;
    private javax.swing.JRadioButton regularRadioBtn;
    private javax.swing.JRadioButton seniorRadioBtn;
    private javax.swing.JButton submitBtn;
    private javax.swing.JComboBox<String> vehicleType;
    // End of variables declaration//GEN-END:variables
}
