
package view.dashboardPanels;
import Controllers.ParkingController;
import Models.Parking;

import java.util.List;
import javax.swing.JOptionPane;


public class ParkingLayoutPanel extends javax.swing.JPanel {

    public ParkingLayoutPanel() {
        initComponents();
        parkedSlot(); //To show slots that are occupied on boot
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel3 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jPanel15 = new javax.swing.JPanel();
        jLabel16 = new javax.swing.JLabel();
        jPanel17 = new javax.swing.JPanel();
        jLabel18 = new javax.swing.JLabel();
        parkingFloor = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel14 = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        jPanel16 = new javax.swing.JPanel();
        jLabel17 = new javax.swing.JLabel();
        p_A1 = new javax.swing.JPanel();
        A1 = new javax.swing.JLabel();
        p_A2 = new javax.swing.JPanel();
        A2 = new javax.swing.JLabel();
        p_A3 = new javax.swing.JPanel();
        A3 = new javax.swing.JLabel();
        p_A4 = new javax.swing.JPanel();
        A4 = new javax.swing.JLabel();
        p_A5 = new javax.swing.JPanel();
        A5 = new javax.swing.JLabel();
        p_A6 = new javax.swing.JPanel();
        A6 = new javax.swing.JLabel();
        p_A7 = new javax.swing.JPanel();
        A7 = new javax.swing.JLabel();
        p_A8 = new javax.swing.JPanel();
        A8 = new javax.swing.JLabel();
        p_A9 = new javax.swing.JPanel();
        A9 = new javax.swing.JLabel();
        p_A10 = new javax.swing.JPanel();
        A10 = new javax.swing.JLabel();
        p_A11 = new javax.swing.JPanel();
        A11 = new javax.swing.JLabel();
        p_A12 = new javax.swing.JPanel();
        A12 = new javax.swing.JLabel();
        p_B1 = new javax.swing.JPanel();
        B1 = new javax.swing.JLabel();
        p_B2 = new javax.swing.JPanel();
        B2 = new javax.swing.JLabel();
        p_B3 = new javax.swing.JPanel();
        B3 = new javax.swing.JLabel();
        p_B4 = new javax.swing.JPanel();
        B4 = new javax.swing.JLabel();
        p_B5 = new javax.swing.JPanel();
        B5 = new javax.swing.JLabel();
        p_B6 = new javax.swing.JPanel();
        B6 = new javax.swing.JLabel();
        p_B7 = new javax.swing.JPanel();
        B7 = new javax.swing.JLabel();
        p_B8 = new javax.swing.JPanel();
        B8 = new javax.swing.JLabel();
        p_B9 = new javax.swing.JPanel();
        B9 = new javax.swing.JLabel();
        p_B10 = new javax.swing.JPanel();
        B11 = new javax.swing.JLabel();
        p_B11 = new javax.swing.JPanel();
        B10 = new javax.swing.JLabel();
        p_B12 = new javax.swing.JPanel();
        B12 = new javax.swing.JLabel();
        p_C1 = new javax.swing.JPanel();
        C1 = new javax.swing.JLabel();
        p_C2 = new javax.swing.JPanel();
        C2 = new javax.swing.JLabel();
        p_C3 = new javax.swing.JPanel();
        C3 = new javax.swing.JLabel();
        p_C4 = new javax.swing.JPanel();
        C4 = new javax.swing.JLabel();
        p_C5 = new javax.swing.JPanel();
        C5 = new javax.swing.JLabel();
        p_C6 = new javax.swing.JPanel();
        C6 = new javax.swing.JLabel();
        p_C7 = new javax.swing.JPanel();
        C7 = new javax.swing.JLabel();
        p_C8 = new javax.swing.JPanel();
        C8 = new javax.swing.JLabel();
        p_C9 = new javax.swing.JPanel();
        C9 = new javax.swing.JLabel();
        p_C10 = new javax.swing.JPanel();
        C11 = new javax.swing.JLabel();
        p_C11 = new javax.swing.JPanel();
        C10 = new javax.swing.JLabel();
        p_C12 = new javax.swing.JPanel();
        C12 = new javax.swing.JLabel();
        p_E1 = new javax.swing.JPanel();
        E1 = new javax.swing.JLabel();
        p_E2 = new javax.swing.JPanel();
        E2 = new javax.swing.JLabel();
        p_E3 = new javax.swing.JPanel();
        E3 = new javax.swing.JLabel();
        p_E4 = new javax.swing.JPanel();
        E4 = new javax.swing.JLabel();
        p_E5 = new javax.swing.JPanel();
        E5 = new javax.swing.JLabel();
        p_E6 = new javax.swing.JPanel();
        E6 = new javax.swing.JLabel();
        p_E7 = new javax.swing.JPanel();
        E7 = new javax.swing.JLabel();
        p_E8 = new javax.swing.JPanel();
        E8 = new javax.swing.JLabel();
        p_E9 = new javax.swing.JPanel();
        E9 = new javax.swing.JLabel();
        p_E10 = new javax.swing.JPanel();
        E10 = new javax.swing.JLabel();
        p_E11 = new javax.swing.JPanel();
        E11 = new javax.swing.JLabel();
        p_E13 = new javax.swing.JPanel();
        E13 = new javax.swing.JLabel();
        p_E12 = new javax.swing.JPanel();
        dumm = new javax.swing.JLabel();
        p_E14 = new javax.swing.JPanel();
        E14 = new javax.swing.JLabel();
        p_E15 = new javax.swing.JPanel();
        E15 = new javax.swing.JLabel();
        p_D1 = new javax.swing.JPanel();
        D1 = new javax.swing.JLabel();
        p_D2 = new javax.swing.JPanel();
        D2 = new javax.swing.JLabel();
        p_D3 = new javax.swing.JPanel();
        D3 = new javax.swing.JLabel();
        p_D4 = new javax.swing.JPanel();
        D4 = new javax.swing.JLabel();
        p_D5 = new javax.swing.JPanel();
        D5 = new javax.swing.JLabel();
        p_D6 = new javax.swing.JPanel();
        D6 = new javax.swing.JLabel();
        p_D7 = new javax.swing.JPanel();
        D7 = new javax.swing.JLabel();
        p_D8 = new javax.swing.JPanel();
        D8 = new javax.swing.JLabel();
        p_D9 = new javax.swing.JPanel();
        D9 = new javax.swing.JLabel();
        p_D10 = new javax.swing.JPanel();
        D10 = new javax.swing.JLabel();
        p_D11 = new javax.swing.JPanel();
        D11 = new javax.swing.JLabel();
        p_D15 = new javax.swing.JPanel();
        D15 = new javax.swing.JLabel();
        p_D14 = new javax.swing.JPanel();
        D14 = new javax.swing.JLabel();
        p_D12 = new javax.swing.JPanel();
        D12 = new javax.swing.JLabel();
        p_D13 = new javax.swing.JPanel();
        D13 = new javax.swing.JLabel();
        p_PWD1 = new javax.swing.JPanel();
        PWD1 = new javax.swing.JLabel();
        p_PWD2 = new javax.swing.JPanel();
        PWD2 = new javax.swing.JLabel();
        p_PWD3 = new javax.swing.JPanel();
        PWD3 = new javax.swing.JLabel();
        p_PWD4 = new javax.swing.JPanel();
        PWD4 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        jPanel10 = new javax.swing.JPanel();
        jPanel11 = new javax.swing.JPanel();
        jPanel12 = new javax.swing.JPanel();
        jPanel13 = new javax.swing.JPanel();
        jPanel18 = new javax.swing.JPanel();
        jPanel19 = new javax.swing.JPanel();
        jPanel20 = new javax.swing.JPanel();
        jPanel21 = new javax.swing.JPanel();
        jPanel22 = new javax.swing.JPanel();
        jPanel23 = new javax.swing.JPanel();
        jPanel24 = new javax.swing.JPanel();
        jPanel32 = new javax.swing.JPanel();
        jPanel33 = new javax.swing.JPanel();
        jPanel34 = new javax.swing.JPanel();
        jPanel35 = new javax.swing.JPanel();
        jPanel36 = new javax.swing.JPanel();
        jPanel37 = new javax.swing.JPanel();
        jPanel38 = new javax.swing.JPanel();
        jPanel39 = new javax.swing.JPanel();
        jPanel40 = new javax.swing.JPanel();
        jPanel41 = new javax.swing.JPanel();
        jPanel42 = new javax.swing.JPanel();
        jPanel43 = new javax.swing.JPanel();
        jPanel44 = new javax.swing.JPanel();
        jPanel45 = new javax.swing.JPanel();
        jPanel46 = new javax.swing.JPanel();
        jPanel47 = new javax.swing.JPanel();
        refresh = new javax.swing.JButton();

        jPanel3.setBackground(new java.awt.Color(144, 238, 144));
        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        jPanel3.setPreferredSize(new java.awt.Dimension(100, 150));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("A-01");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(jLabel4)
                .addContainerGap(34, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(56, 56, 56)
                .addComponent(jLabel4)
                .addContainerGap(70, Short.MAX_VALUE))
        );

        jPanel7.setBackground(new java.awt.Color(144, 238, 144));
        jPanel7.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        jPanel7.setPreferredSize(new java.awt.Dimension(100, 150));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel8.setText("A1");

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                .addContainerGap(40, Short.MAX_VALUE)
                .addComponent(jLabel8)
                .addGap(38, 38, 38))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(58, 58, 58)
                .addComponent(jLabel8)
                .addContainerGap(68, Short.MAX_VALUE))
        );

        jPanel9.setBackground(new java.awt.Color(144, 238, 144));
        jPanel9.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        jPanel9.setPreferredSize(new java.awt.Dimension(100, 150));

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel10.setText("A1");

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                .addContainerGap(40, Short.MAX_VALUE)
                .addComponent(jLabel10)
                .addGap(38, 38, 38))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(58, 58, 58)
                .addComponent(jLabel10)
                .addContainerGap(68, Short.MAX_VALUE))
        );

        jPanel15.setBackground(new java.awt.Color(144, 238, 144));
        jPanel15.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        jPanel15.setPreferredSize(new java.awt.Dimension(100, 150));

        jLabel16.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel16.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel16.setText("A1");

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel15Layout.createSequentialGroup()
                .addContainerGap(40, Short.MAX_VALUE)
                .addComponent(jLabel16)
                .addGap(38, 38, 38))
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addGap(58, 58, 58)
                .addComponent(jLabel16)
                .addContainerGap(68, Short.MAX_VALUE))
        );

        jPanel17.setBackground(new java.awt.Color(144, 238, 144));
        jPanel17.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        jPanel17.setPreferredSize(new java.awt.Dimension(100, 150));

        jLabel18.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel18.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel18.setText("A1");

        javax.swing.GroupLayout jPanel17Layout = new javax.swing.GroupLayout(jPanel17);
        jPanel17.setLayout(jPanel17Layout);
        jPanel17Layout.setHorizontalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel17Layout.createSequentialGroup()
                .addContainerGap(40, Short.MAX_VALUE)
                .addComponent(jLabel18)
                .addGap(38, 38, 38))
        );
        jPanel17Layout.setVerticalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel17Layout.createSequentialGroup()
                .addGap(58, 58, 58)
                .addComponent(jLabel18)
                .addContainerGap(68, Short.MAX_VALUE))
        );

        setBackground(new java.awt.Color(204, 204, 204));

        parkingFloor.setBackground(new java.awt.Color(204, 204, 204));
        parkingFloor.setPreferredSize(new java.awt.Dimension(1098, 766));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setText("PARKING LAYOUT");

        jPanel14.setBackground(new java.awt.Color(102, 102, 102));
        jPanel14.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        jPanel14.setForeground(new java.awt.Color(255, 255, 255));
        jPanel14.setPreferredSize(new java.awt.Dimension(100, 150));
        jPanel14.setLayout(new java.awt.BorderLayout());

        jLabel15.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel15.setText("EXIT");
        jPanel14.add(jLabel15, java.awt.BorderLayout.CENTER);

        jPanel16.setBackground(new java.awt.Color(102, 102, 102));
        jPanel16.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        jPanel16.setForeground(new java.awt.Color(255, 255, 255));
        jPanel16.setPreferredSize(new java.awt.Dimension(100, 150));
        jPanel16.setLayout(new java.awt.BorderLayout());

        jLabel17.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(255, 255, 255));
        jLabel17.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel17.setText("ENTRANCE");
        jPanel16.add(jLabel17, java.awt.BorderLayout.CENTER);

        p_A1.setBackground(new java.awt.Color(134, 239, 172));
        p_A1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_A1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_A1.setName("A1"); // NOI18N
        p_A1.setPreferredSize(new java.awt.Dimension(100, 150));
        p_A1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_CarMouseClicked(evt);
            }
        });
        p_A1.setLayout(new java.awt.BorderLayout());

        A1.setBackground(new java.awt.Color(255, 255, 255));
        A1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        A1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        A1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/carParkIcon.png"))); // NOI18N
        A1.setText("A1");
        A1.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        A1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        A1.setIconTextGap(20);
        A1.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_A1.add(A1, java.awt.BorderLayout.CENTER);

        p_A2.setBackground(new java.awt.Color(134, 239, 172));
        p_A2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_A2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_A2.setName("A2"); // NOI18N
        p_A2.setPreferredSize(new java.awt.Dimension(100, 150));
        p_A2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_CarMouseClicked(evt);
            }
        });
        p_A2.setLayout(new java.awt.BorderLayout());

        A2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        A2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        A2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/carParkIcon.png"))); // NOI18N
        A2.setText("A2");
        A2.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        A2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        A2.setIconTextGap(20);
        A2.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_A2.add(A2, java.awt.BorderLayout.CENTER);

        p_A3.setBackground(new java.awt.Color(134, 239, 172));
        p_A3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_A3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_A3.setName("A3"); // NOI18N
        p_A3.setPreferredSize(new java.awt.Dimension(100, 150));
        p_A3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_CarMouseClicked(evt);
            }
        });
        p_A3.setLayout(new java.awt.BorderLayout());

        A3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        A3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        A3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/carParkIcon.png"))); // NOI18N
        A3.setText("A3");
        A3.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        A3.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        A3.setIconTextGap(20);
        A3.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_A3.add(A3, java.awt.BorderLayout.CENTER);

        p_A4.setBackground(new java.awt.Color(134, 239, 172));
        p_A4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_A4.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_A4.setName("A4"); // NOI18N
        p_A4.setPreferredSize(new java.awt.Dimension(100, 150));
        p_A4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_CarMouseClicked(evt);
            }
        });
        p_A4.setLayout(new java.awt.BorderLayout());

        A4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        A4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        A4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/carParkIcon.png"))); // NOI18N
        A4.setText("A4");
        A4.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        A4.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        A4.setIconTextGap(20);
        A4.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_A4.add(A4, java.awt.BorderLayout.CENTER);

        p_A5.setBackground(new java.awt.Color(134, 239, 172));
        p_A5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_A5.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_A5.setName("A5"); // NOI18N
        p_A5.setPreferredSize(new java.awt.Dimension(100, 150));
        p_A5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_CarMouseClicked(evt);
            }
        });
        p_A5.setLayout(new java.awt.BorderLayout());

        A5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        A5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        A5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/carParkIcon.png"))); // NOI18N
        A5.setText("A5");
        A5.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        A5.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        A5.setIconTextGap(20);
        A5.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_A5.add(A5, java.awt.BorderLayout.CENTER);

        p_A6.setBackground(new java.awt.Color(134, 239, 172));
        p_A6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_A6.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_A6.setName("A6"); // NOI18N
        p_A6.setPreferredSize(new java.awt.Dimension(100, 150));
        p_A6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_CarMouseClicked(evt);
            }
        });
        p_A6.setLayout(new java.awt.BorderLayout());

        A6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        A6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        A6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/carParkIcon.png"))); // NOI18N
        A6.setText("A6");
        A6.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        A6.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        A6.setIconTextGap(20);
        A6.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_A6.add(A6, java.awt.BorderLayout.CENTER);

        p_A7.setBackground(new java.awt.Color(134, 239, 172));
        p_A7.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_A7.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_A7.setName("A7"); // NOI18N
        p_A7.setPreferredSize(new java.awt.Dimension(100, 150));
        p_A7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_CarMouseClicked(evt);
            }
        });
        p_A7.setLayout(new java.awt.BorderLayout());

        A7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        A7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        A7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/carParkIcon.png"))); // NOI18N
        A7.setText("A7");
        A7.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        A7.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        A7.setIconTextGap(20);
        A7.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_A7.add(A7, java.awt.BorderLayout.CENTER);

        p_A8.setBackground(new java.awt.Color(134, 239, 172));
        p_A8.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_A8.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_A8.setName("A8"); // NOI18N
        p_A8.setPreferredSize(new java.awt.Dimension(100, 150));
        p_A8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_CarMouseClicked(evt);
            }
        });
        p_A8.setLayout(new java.awt.BorderLayout());

        A8.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        A8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        A8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/carParkIcon.png"))); // NOI18N
        A8.setText("A8");
        A8.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        A8.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        A8.setIconTextGap(20);
        A8.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_A8.add(A8, java.awt.BorderLayout.CENTER);

        p_A9.setBackground(new java.awt.Color(134, 239, 172));
        p_A9.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_A9.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_A9.setName("A9"); // NOI18N
        p_A9.setPreferredSize(new java.awt.Dimension(100, 150));
        p_A9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_CarMouseClicked(evt);
            }
        });
        p_A9.setLayout(new java.awt.BorderLayout());

        A9.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        A9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        A9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/carParkIcon.png"))); // NOI18N
        A9.setText("A9");
        A9.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        A9.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        A9.setIconTextGap(20);
        A9.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_A9.add(A9, java.awt.BorderLayout.CENTER);

        p_A10.setBackground(new java.awt.Color(134, 239, 172));
        p_A10.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_A10.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_A10.setName("A10"); // NOI18N
        p_A10.setPreferredSize(new java.awt.Dimension(100, 150));
        p_A10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_CarMouseClicked(evt);
            }
        });
        p_A10.setLayout(new java.awt.BorderLayout());

        A10.setBackground(new java.awt.Color(255, 102, 102));
        A10.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        A10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        A10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/carParkIcon.png"))); // NOI18N
        A10.setText("A10");
        A10.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        A10.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        A10.setIconTextGap(20);
        A10.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_A10.add(A10, java.awt.BorderLayout.CENTER);

        p_A11.setBackground(new java.awt.Color(134, 239, 172));
        p_A11.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_A11.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_A11.setName("A11"); // NOI18N
        p_A11.setPreferredSize(new java.awt.Dimension(100, 150));
        p_A11.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_CarMouseClicked(evt);
            }
        });
        p_A11.setLayout(new java.awt.BorderLayout());

        A11.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        A11.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        A11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/carParkIcon.png"))); // NOI18N
        A11.setText("A11");
        A11.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        A11.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        A11.setIconTextGap(20);
        A11.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_A11.add(A11, java.awt.BorderLayout.CENTER);

        p_A12.setBackground(new java.awt.Color(134, 239, 172));
        p_A12.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_A12.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_A12.setName("A12"); // NOI18N
        p_A12.setPreferredSize(new java.awt.Dimension(100, 150));
        p_A12.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_CarMouseClicked(evt);
            }
        });
        p_A12.setLayout(new java.awt.BorderLayout());

        A12.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        A12.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        A12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/carParkIcon.png"))); // NOI18N
        A12.setText("A12");
        A12.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        A12.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        A12.setIconTextGap(20);
        A12.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_A12.add(A12, java.awt.BorderLayout.CENTER);

        p_B1.setBackground(new java.awt.Color(134, 239, 172));
        p_B1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_B1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_B1.setName("B1"); // NOI18N
        p_B1.setPreferredSize(new java.awt.Dimension(100, 150));
        p_B1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_CarMouseClicked(evt);
            }
        });
        p_B1.setLayout(new java.awt.BorderLayout());

        B1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        B1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        B1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/carParkIcon.png"))); // NOI18N
        B1.setText("B1");
        B1.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        B1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        B1.setIconTextGap(20);
        B1.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_B1.add(B1, java.awt.BorderLayout.CENTER);

        p_B2.setBackground(new java.awt.Color(134, 239, 172));
        p_B2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_B2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_B2.setName("B2"); // NOI18N
        p_B2.setPreferredSize(new java.awt.Dimension(100, 150));
        p_B2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_CarMouseClicked(evt);
            }
        });
        p_B2.setLayout(new java.awt.BorderLayout());

        B2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        B2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        B2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/carParkIcon.png"))); // NOI18N
        B2.setText("B2");
        B2.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        B2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        B2.setIconTextGap(20);
        B2.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_B2.add(B2, java.awt.BorderLayout.CENTER);

        p_B3.setBackground(new java.awt.Color(134, 239, 172));
        p_B3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_B3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_B3.setName("B3"); // NOI18N
        p_B3.setPreferredSize(new java.awt.Dimension(100, 150));
        p_B3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_CarMouseClicked(evt);
            }
        });
        p_B3.setLayout(new java.awt.BorderLayout());

        B3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        B3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        B3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/carParkIcon.png"))); // NOI18N
        B3.setText("B3");
        B3.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        B3.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        B3.setIconTextGap(20);
        B3.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_B3.add(B3, java.awt.BorderLayout.CENTER);

        p_B4.setBackground(new java.awt.Color(134, 239, 172));
        p_B4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_B4.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_B4.setName("B4"); // NOI18N
        p_B4.setPreferredSize(new java.awt.Dimension(100, 150));
        p_B4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_CarMouseClicked(evt);
            }
        });
        p_B4.setLayout(new java.awt.BorderLayout());

        B4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        B4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        B4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/carParkIcon.png"))); // NOI18N
        B4.setText("B4");
        B4.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        B4.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        B4.setIconTextGap(20);
        B4.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_B4.add(B4, java.awt.BorderLayout.CENTER);

        p_B5.setBackground(new java.awt.Color(134, 239, 172));
        p_B5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_B5.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_B5.setName("B5"); // NOI18N
        p_B5.setPreferredSize(new java.awt.Dimension(100, 150));
        p_B5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_CarMouseClicked(evt);
            }
        });
        p_B5.setLayout(new java.awt.BorderLayout());

        B5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        B5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        B5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/carParkIcon.png"))); // NOI18N
        B5.setText("B5");
        B5.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        B5.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        B5.setIconTextGap(20);
        B5.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_B5.add(B5, java.awt.BorderLayout.CENTER);

        p_B6.setBackground(new java.awt.Color(134, 239, 172));
        p_B6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_B6.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_B6.setName("B6"); // NOI18N
        p_B6.setPreferredSize(new java.awt.Dimension(100, 150));
        p_B6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_CarMouseClicked(evt);
            }
        });
        p_B6.setLayout(new java.awt.BorderLayout());

        B6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        B6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        B6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/carParkIcon.png"))); // NOI18N
        B6.setText("B6");
        B6.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        B6.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        B6.setIconTextGap(20);
        B6.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_B6.add(B6, java.awt.BorderLayout.CENTER);

        p_B7.setBackground(new java.awt.Color(134, 239, 172));
        p_B7.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_B7.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_B7.setName("B7"); // NOI18N
        p_B7.setPreferredSize(new java.awt.Dimension(100, 150));
        p_B7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_CarMouseClicked(evt);
            }
        });
        p_B7.setLayout(new java.awt.BorderLayout());

        B7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        B7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        B7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/carParkIcon.png"))); // NOI18N
        B7.setText("B7");
        B7.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        B7.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        B7.setIconTextGap(20);
        B7.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_B7.add(B7, java.awt.BorderLayout.CENTER);

        p_B8.setBackground(new java.awt.Color(134, 239, 172));
        p_B8.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_B8.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_B8.setName("B8"); // NOI18N
        p_B8.setPreferredSize(new java.awt.Dimension(100, 150));
        p_B8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_CarMouseClicked(evt);
            }
        });
        p_B8.setLayout(new java.awt.BorderLayout());

        B8.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        B8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        B8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/carParkIcon.png"))); // NOI18N
        B8.setText("B8");
        B8.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        B8.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        B8.setIconTextGap(20);
        B8.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_B8.add(B8, java.awt.BorderLayout.CENTER);

        p_B9.setBackground(new java.awt.Color(134, 239, 172));
        p_B9.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_B9.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_B9.setName("B9"); // NOI18N
        p_B9.setPreferredSize(new java.awt.Dimension(100, 150));
        p_B9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_CarMouseClicked(evt);
            }
        });
        p_B9.setLayout(new java.awt.BorderLayout());

        B9.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        B9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        B9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/carParkIcon.png"))); // NOI18N
        B9.setText("B9");
        B9.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        B9.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        B9.setIconTextGap(20);
        B9.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_B9.add(B9, java.awt.BorderLayout.CENTER);

        p_B10.setBackground(new java.awt.Color(134, 239, 172));
        p_B10.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_B10.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_B10.setName("B10"); // NOI18N
        p_B10.setPreferredSize(new java.awt.Dimension(100, 150));
        p_B10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_CarMouseClicked(evt);
            }
        });
        p_B10.setLayout(new java.awt.BorderLayout());

        B11.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        B11.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        B11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/carParkIcon.png"))); // NOI18N
        B11.setText("B10");
        B11.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        B11.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        B11.setIconTextGap(20);
        B11.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_B10.add(B11, java.awt.BorderLayout.CENTER);

        p_B11.setBackground(new java.awt.Color(134, 239, 172));
        p_B11.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_B11.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_B11.setName("B11"); // NOI18N
        p_B11.setPreferredSize(new java.awt.Dimension(100, 150));
        p_B11.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_CarMouseClicked(evt);
            }
        });
        p_B11.setLayout(new java.awt.BorderLayout());

        B10.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        B10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        B10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/carParkIcon.png"))); // NOI18N
        B10.setText("B11");
        B10.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        B10.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        B10.setIconTextGap(20);
        B10.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_B11.add(B10, java.awt.BorderLayout.CENTER);

        p_B12.setBackground(new java.awt.Color(134, 239, 172));
        p_B12.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_B12.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_B12.setName("B12"); // NOI18N
        p_B12.setPreferredSize(new java.awt.Dimension(100, 150));
        p_B12.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_CarMouseClicked(evt);
            }
        });
        p_B12.setLayout(new java.awt.BorderLayout());

        B12.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        B12.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        B12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/carParkIcon.png"))); // NOI18N
        B12.setText("B12");
        B12.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        B12.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        B12.setIconTextGap(20);
        B12.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_B12.add(B12, java.awt.BorderLayout.CENTER);

        p_C1.setBackground(new java.awt.Color(134, 239, 172));
        p_C1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_C1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_C1.setName("C1"); // NOI18N
        p_C1.setPreferredSize(new java.awt.Dimension(100, 150));
        p_C1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_CarMouseClicked(evt);
            }
        });
        p_C1.setLayout(new java.awt.BorderLayout());

        C1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        C1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        C1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/carParkIcon.png"))); // NOI18N
        C1.setText("C1");
        C1.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        C1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        C1.setIconTextGap(20);
        C1.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_C1.add(C1, java.awt.BorderLayout.CENTER);

        p_C2.setBackground(new java.awt.Color(134, 239, 172));
        p_C2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_C2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_C2.setName("C2"); // NOI18N
        p_C2.setPreferredSize(new java.awt.Dimension(100, 150));
        p_C2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_CarMouseClicked(evt);
            }
        });
        p_C2.setLayout(new java.awt.BorderLayout());

        C2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        C2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        C2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/carParkIcon.png"))); // NOI18N
        C2.setText("C2");
        C2.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        C2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        C2.setIconTextGap(20);
        C2.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_C2.add(C2, java.awt.BorderLayout.CENTER);

        p_C3.setBackground(new java.awt.Color(134, 239, 172));
        p_C3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_C3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_C3.setName("C3"); // NOI18N
        p_C3.setPreferredSize(new java.awt.Dimension(100, 150));
        p_C3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_CarMouseClicked(evt);
            }
        });
        p_C3.setLayout(new java.awt.BorderLayout());

        C3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        C3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        C3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/carParkIcon.png"))); // NOI18N
        C3.setText("C3");
        C3.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        C3.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        C3.setIconTextGap(20);
        C3.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_C3.add(C3, java.awt.BorderLayout.CENTER);

        p_C4.setBackground(new java.awt.Color(134, 239, 172));
        p_C4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_C4.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_C4.setName("C4"); // NOI18N
        p_C4.setPreferredSize(new java.awt.Dimension(100, 150));
        p_C4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_CarMouseClicked(evt);
            }
        });
        p_C4.setLayout(new java.awt.BorderLayout());

        C4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        C4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        C4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/carParkIcon.png"))); // NOI18N
        C4.setText("C4");
        C4.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        C4.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        C4.setIconTextGap(20);
        C4.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_C4.add(C4, java.awt.BorderLayout.CENTER);

        p_C5.setBackground(new java.awt.Color(134, 239, 172));
        p_C5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_C5.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_C5.setName("C5"); // NOI18N
        p_C5.setPreferredSize(new java.awt.Dimension(100, 150));
        p_C5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_CarMouseClicked(evt);
            }
        });
        p_C5.setLayout(new java.awt.BorderLayout());

        C5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        C5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        C5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/carParkIcon.png"))); // NOI18N
        C5.setText("C5");
        C5.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        C5.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        C5.setIconTextGap(20);
        C5.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_C5.add(C5, java.awt.BorderLayout.CENTER);

        p_C6.setBackground(new java.awt.Color(134, 239, 172));
        p_C6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_C6.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_C6.setName("C6"); // NOI18N
        p_C6.setPreferredSize(new java.awt.Dimension(100, 150));
        p_C6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_CarMouseClicked(evt);
            }
        });
        p_C6.setLayout(new java.awt.BorderLayout());

        C6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        C6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        C6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/carParkIcon.png"))); // NOI18N
        C6.setText("C6");
        C6.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        C6.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        C6.setIconTextGap(20);
        C6.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_C6.add(C6, java.awt.BorderLayout.CENTER);

        p_C7.setBackground(new java.awt.Color(134, 239, 172));
        p_C7.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_C7.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_C7.setName("C7"); // NOI18N
        p_C7.setPreferredSize(new java.awt.Dimension(100, 150));
        p_C7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_CarMouseClicked(evt);
            }
        });
        p_C7.setLayout(new java.awt.BorderLayout());

        C7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        C7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        C7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/carParkIcon.png"))); // NOI18N
        C7.setText("C7");
        C7.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        C7.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        C7.setIconTextGap(20);
        C7.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_C7.add(C7, java.awt.BorderLayout.CENTER);

        p_C8.setBackground(new java.awt.Color(134, 239, 172));
        p_C8.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_C8.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_C8.setName("C8"); // NOI18N
        p_C8.setPreferredSize(new java.awt.Dimension(100, 150));
        p_C8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_CarMouseClicked(evt);
            }
        });
        p_C8.setLayout(new java.awt.BorderLayout());

        C8.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        C8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        C8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/carParkIcon.png"))); // NOI18N
        C8.setText("C8");
        C8.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        C8.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        C8.setIconTextGap(20);
        C8.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_C8.add(C8, java.awt.BorderLayout.CENTER);

        p_C9.setBackground(new java.awt.Color(134, 239, 172));
        p_C9.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_C9.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_C9.setName("C9"); // NOI18N
        p_C9.setPreferredSize(new java.awt.Dimension(100, 150));
        p_C9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_CarMouseClicked(evt);
            }
        });
        p_C9.setLayout(new java.awt.BorderLayout());

        C9.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        C9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        C9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/carParkIcon.png"))); // NOI18N
        C9.setText("C9");
        C9.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        C9.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        C9.setIconTextGap(20);
        C9.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_C9.add(C9, java.awt.BorderLayout.CENTER);

        p_C10.setBackground(new java.awt.Color(134, 239, 172));
        p_C10.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_C10.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_C10.setName("C10"); // NOI18N
        p_C10.setPreferredSize(new java.awt.Dimension(100, 150));
        p_C10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_CarMouseClicked(evt);
            }
        });
        p_C10.setLayout(new java.awt.BorderLayout());

        C11.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        C11.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        C11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/carParkIcon.png"))); // NOI18N
        C11.setText("C10");
        C11.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        C11.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        C11.setIconTextGap(20);
        C11.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_C10.add(C11, java.awt.BorderLayout.CENTER);

        p_C11.setBackground(new java.awt.Color(134, 239, 172));
        p_C11.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_C11.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_C11.setName("C11"); // NOI18N
        p_C11.setPreferredSize(new java.awt.Dimension(100, 150));
        p_C11.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_CarMouseClicked(evt);
            }
        });
        p_C11.setLayout(new java.awt.BorderLayout());

        C10.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        C10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        C10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/carParkIcon.png"))); // NOI18N
        C10.setText("C11");
        C10.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        C10.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        C10.setIconTextGap(20);
        C10.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_C11.add(C10, java.awt.BorderLayout.CENTER);

        p_C12.setBackground(new java.awt.Color(134, 239, 172));
        p_C12.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_C12.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_C12.setName("C12"); // NOI18N
        p_C12.setPreferredSize(new java.awt.Dimension(100, 150));
        p_C12.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_CarMouseClicked(evt);
            }
        });
        p_C12.setLayout(new java.awt.BorderLayout());

        C12.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        C12.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        C12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/carParkIcon.png"))); // NOI18N
        C12.setText("C12");
        C12.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        C12.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        C12.setIconTextGap(20);
        C12.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_C12.add(C12, java.awt.BorderLayout.CENTER);

        p_E1.setBackground(new java.awt.Color(134, 239, 172));
        p_E1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_E1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_E1.setName("E1"); // NOI18N
        p_E1.setPreferredSize(new java.awt.Dimension(50, 75));
        p_E1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_MotorMouseClicked(evt);
            }
        });
        p_E1.setLayout(new java.awt.BorderLayout());

        E1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        E1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        E1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/motorIcon.png"))); // NOI18N
        E1.setText("E1");
        E1.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        E1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        E1.setIconTextGap(10);
        E1.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_E1.add(E1, java.awt.BorderLayout.CENTER);

        p_E2.setBackground(new java.awt.Color(134, 239, 172));
        p_E2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_E2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_E2.setName("E2"); // NOI18N
        p_E2.setPreferredSize(new java.awt.Dimension(50, 75));
        p_E2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_MotorMouseClicked(evt);
            }
        });
        p_E2.setLayout(new java.awt.BorderLayout());

        E2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        E2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        E2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/motorIcon.png"))); // NOI18N
        E2.setText("E2");
        E2.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        E2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        E2.setIconTextGap(10);
        E2.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_E2.add(E2, java.awt.BorderLayout.CENTER);

        p_E3.setBackground(new java.awt.Color(134, 239, 172));
        p_E3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_E3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_E3.setName("E3"); // NOI18N
        p_E3.setPreferredSize(new java.awt.Dimension(50, 75));
        p_E3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_MotorMouseClicked(evt);
            }
        });
        p_E3.setLayout(new java.awt.BorderLayout());

        E3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        E3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        E3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/motorIcon.png"))); // NOI18N
        E3.setText("E3");
        E3.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        E3.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        E3.setIconTextGap(10);
        E3.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_E3.add(E3, java.awt.BorderLayout.CENTER);

        p_E4.setBackground(new java.awt.Color(134, 239, 172));
        p_E4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_E4.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_E4.setName("E4"); // NOI18N
        p_E4.setPreferredSize(new java.awt.Dimension(50, 75));
        p_E4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_MotorMouseClicked(evt);
            }
        });
        p_E4.setLayout(new java.awt.BorderLayout());

        E4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        E4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        E4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/motorIcon.png"))); // NOI18N
        E4.setText("E4");
        E4.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        E4.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        E4.setIconTextGap(10);
        E4.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_E4.add(E4, java.awt.BorderLayout.CENTER);

        p_E5.setBackground(new java.awt.Color(134, 239, 172));
        p_E5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_E5.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_E5.setName("E5"); // NOI18N
        p_E5.setPreferredSize(new java.awt.Dimension(50, 75));
        p_E5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_MotorMouseClicked(evt);
            }
        });
        p_E5.setLayout(new java.awt.BorderLayout());

        E5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        E5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        E5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/motorIcon.png"))); // NOI18N
        E5.setText("E5");
        E5.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        E5.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        E5.setIconTextGap(10);
        E5.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_E5.add(E5, java.awt.BorderLayout.CENTER);

        p_E6.setBackground(new java.awt.Color(134, 239, 172));
        p_E6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_E6.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_E6.setName("E6"); // NOI18N
        p_E6.setPreferredSize(new java.awt.Dimension(50, 75));
        p_E6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_MotorMouseClicked(evt);
            }
        });
        p_E6.setLayout(new java.awt.BorderLayout());

        E6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        E6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        E6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/motorIcon.png"))); // NOI18N
        E6.setText("E6");
        E6.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        E6.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        E6.setIconTextGap(10);
        E6.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_E6.add(E6, java.awt.BorderLayout.CENTER);

        p_E7.setBackground(new java.awt.Color(134, 239, 172));
        p_E7.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_E7.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_E7.setName("E7"); // NOI18N
        p_E7.setPreferredSize(new java.awt.Dimension(50, 75));
        p_E7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_MotorMouseClicked(evt);
            }
        });
        p_E7.setLayout(new java.awt.BorderLayout());

        E7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        E7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        E7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/motorIcon.png"))); // NOI18N
        E7.setText("E7");
        E7.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        E7.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        E7.setIconTextGap(10);
        E7.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_E7.add(E7, java.awt.BorderLayout.CENTER);

        p_E8.setBackground(new java.awt.Color(134, 239, 172));
        p_E8.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_E8.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_E8.setName("E8"); // NOI18N
        p_E8.setPreferredSize(new java.awt.Dimension(50, 75));
        p_E8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_MotorMouseClicked(evt);
            }
        });
        p_E8.setLayout(new java.awt.BorderLayout());

        E8.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        E8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        E8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/motorIcon.png"))); // NOI18N
        E8.setText("E8");
        E8.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        E8.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        E8.setIconTextGap(10);
        E8.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_E8.add(E8, java.awt.BorderLayout.CENTER);

        p_E9.setBackground(new java.awt.Color(134, 239, 172));
        p_E9.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_E9.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_E9.setName("E9"); // NOI18N
        p_E9.setPreferredSize(new java.awt.Dimension(50, 75));
        p_E9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_MotorMouseClicked(evt);
            }
        });
        p_E9.setLayout(new java.awt.BorderLayout());

        E9.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        E9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        E9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/motorIcon.png"))); // NOI18N
        E9.setText("E9");
        E9.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        E9.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        E9.setIconTextGap(10);
        E9.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_E9.add(E9, java.awt.BorderLayout.CENTER);

        p_E10.setBackground(new java.awt.Color(134, 239, 172));
        p_E10.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_E10.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_E10.setName("E10"); // NOI18N
        p_E10.setPreferredSize(new java.awt.Dimension(50, 75));
        p_E10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_MotorMouseClicked(evt);
            }
        });
        p_E10.setLayout(new java.awt.BorderLayout());

        E10.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        E10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        E10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/motorIcon.png"))); // NOI18N
        E10.setText("E10");
        E10.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        E10.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        E10.setIconTextGap(10);
        E10.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_E10.add(E10, java.awt.BorderLayout.CENTER);

        p_E11.setBackground(new java.awt.Color(134, 239, 172));
        p_E11.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_E11.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_E11.setName("E11"); // NOI18N
        p_E11.setPreferredSize(new java.awt.Dimension(50, 75));
        p_E11.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_MotorMouseClicked(evt);
            }
        });
        p_E11.setLayout(new java.awt.BorderLayout());

        E11.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        E11.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        E11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/motorIcon.png"))); // NOI18N
        E11.setText("E11");
        E11.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        E11.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        E11.setIconTextGap(10);
        E11.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_E11.add(E11, java.awt.BorderLayout.CENTER);

        p_E13.setBackground(new java.awt.Color(134, 239, 172));
        p_E13.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_E13.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_E13.setName("E13"); // NOI18N
        p_E13.setPreferredSize(new java.awt.Dimension(50, 75));
        p_E13.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_MotorMouseClicked(evt);
            }
        });
        p_E13.setLayout(new java.awt.BorderLayout());

        E13.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        E13.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        E13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/motorIcon.png"))); // NOI18N
        E13.setText("E13");
        E13.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        E13.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        E13.setIconTextGap(10);
        E13.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_E13.add(E13, java.awt.BorderLayout.CENTER);

        p_E12.setBackground(new java.awt.Color(134, 239, 172));
        p_E12.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_E12.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_E12.setName("E12"); // NOI18N
        p_E12.setPreferredSize(new java.awt.Dimension(50, 75));
        p_E12.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_MotorMouseClicked(evt);
            }
        });
        p_E12.setLayout(new java.awt.BorderLayout());

        dumm.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        dumm.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        dumm.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/motorIcon.png"))); // NOI18N
        dumm.setText("E12");
        dumm.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        dumm.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        dumm.setIconTextGap(10);
        dumm.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_E12.add(dumm, java.awt.BorderLayout.CENTER);

        p_E14.setBackground(new java.awt.Color(134, 239, 172));
        p_E14.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_E14.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_E14.setName("E14"); // NOI18N
        p_E14.setPreferredSize(new java.awt.Dimension(50, 75));
        p_E14.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_MotorMouseClicked(evt);
            }
        });
        p_E14.setLayout(new java.awt.BorderLayout());

        E14.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        E14.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        E14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/motorIcon.png"))); // NOI18N
        E14.setText("E14");
        E14.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        E14.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        E14.setIconTextGap(10);
        E14.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_E14.add(E14, java.awt.BorderLayout.CENTER);

        p_E15.setBackground(new java.awt.Color(134, 239, 172));
        p_E15.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_E15.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_E15.setName("E15"); // NOI18N
        p_E15.setPreferredSize(new java.awt.Dimension(50, 75));
        p_E15.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_MotorMouseClicked(evt);
            }
        });
        p_E15.setLayout(new java.awt.BorderLayout());

        E15.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        E15.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        E15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/motorIcon.png"))); // NOI18N
        E15.setText("E15");
        E15.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        E15.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        E15.setIconTextGap(10);
        E15.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_E15.add(E15, java.awt.BorderLayout.CENTER);

        p_D1.setBackground(new java.awt.Color(134, 239, 172));
        p_D1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_D1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_D1.setName("D1"); // NOI18N
        p_D1.setPreferredSize(new java.awt.Dimension(50, 75));
        p_D1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_MotorMouseClicked(evt);
            }
        });
        p_D1.setLayout(new java.awt.BorderLayout());

        D1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        D1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        D1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/motorIcon.png"))); // NOI18N
        D1.setText("D1");
        D1.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        D1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        D1.setIconTextGap(10);
        D1.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_D1.add(D1, java.awt.BorderLayout.CENTER);

        p_D2.setBackground(new java.awt.Color(134, 239, 172));
        p_D2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_D2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_D2.setName("D2"); // NOI18N
        p_D2.setPreferredSize(new java.awt.Dimension(50, 75));
        p_D2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_MotorMouseClicked(evt);
            }
        });
        p_D2.setLayout(new java.awt.BorderLayout());

        D2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        D2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        D2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/motorIcon.png"))); // NOI18N
        D2.setText("D2");
        D2.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        D2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        D2.setIconTextGap(10);
        D2.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_D2.add(D2, java.awt.BorderLayout.CENTER);

        p_D3.setBackground(new java.awt.Color(134, 239, 172));
        p_D3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_D3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_D3.setName("D3"); // NOI18N
        p_D3.setPreferredSize(new java.awt.Dimension(50, 75));
        p_D3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_MotorMouseClicked(evt);
            }
        });
        p_D3.setLayout(new java.awt.BorderLayout());

        D3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        D3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        D3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/motorIcon.png"))); // NOI18N
        D3.setText("D3");
        D3.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        D3.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        D3.setIconTextGap(10);
        D3.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_D3.add(D3, java.awt.BorderLayout.CENTER);

        p_D4.setBackground(new java.awt.Color(134, 239, 172));
        p_D4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_D4.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_D4.setName("D4"); // NOI18N
        p_D4.setPreferredSize(new java.awt.Dimension(50, 75));
        p_D4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_MotorMouseClicked(evt);
            }
        });
        p_D4.setLayout(new java.awt.BorderLayout());

        D4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        D4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        D4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/motorIcon.png"))); // NOI18N
        D4.setText("D4");
        D4.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        D4.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        D4.setIconTextGap(10);
        D4.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_D4.add(D4, java.awt.BorderLayout.CENTER);

        p_D5.setBackground(new java.awt.Color(134, 239, 172));
        p_D5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_D5.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_D5.setName("D5"); // NOI18N
        p_D5.setPreferredSize(new java.awt.Dimension(50, 75));
        p_D5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_MotorMouseClicked(evt);
            }
        });
        p_D5.setLayout(new java.awt.BorderLayout());

        D5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        D5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        D5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/motorIcon.png"))); // NOI18N
        D5.setText("D5");
        D5.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        D5.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        D5.setIconTextGap(10);
        D5.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_D5.add(D5, java.awt.BorderLayout.CENTER);

        p_D6.setBackground(new java.awt.Color(134, 239, 172));
        p_D6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_D6.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_D6.setName("D6"); // NOI18N
        p_D6.setPreferredSize(new java.awt.Dimension(50, 75));
        p_D6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_MotorMouseClicked(evt);
            }
        });
        p_D6.setLayout(new java.awt.BorderLayout());

        D6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        D6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        D6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/motorIcon.png"))); // NOI18N
        D6.setText("D6");
        D6.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        D6.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        D6.setIconTextGap(10);
        D6.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_D6.add(D6, java.awt.BorderLayout.CENTER);

        p_D7.setBackground(new java.awt.Color(134, 239, 172));
        p_D7.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_D7.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_D7.setName("D7"); // NOI18N
        p_D7.setPreferredSize(new java.awt.Dimension(50, 75));
        p_D7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_MotorMouseClicked(evt);
            }
        });
        p_D7.setLayout(new java.awt.BorderLayout());

        D7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        D7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        D7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/motorIcon.png"))); // NOI18N
        D7.setText("D7");
        D7.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        D7.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        D7.setIconTextGap(10);
        D7.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_D7.add(D7, java.awt.BorderLayout.CENTER);

        p_D8.setBackground(new java.awt.Color(134, 239, 172));
        p_D8.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_D8.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_D8.setName("D8"); // NOI18N
        p_D8.setPreferredSize(new java.awt.Dimension(50, 75));
        p_D8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_MotorMouseClicked(evt);
            }
        });
        p_D8.setLayout(new java.awt.BorderLayout());

        D8.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        D8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        D8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/motorIcon.png"))); // NOI18N
        D8.setText("D8");
        D8.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        D8.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        D8.setIconTextGap(10);
        D8.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_D8.add(D8, java.awt.BorderLayout.CENTER);

        p_D9.setBackground(new java.awt.Color(134, 239, 172));
        p_D9.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_D9.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_D9.setName("D9"); // NOI18N
        p_D9.setPreferredSize(new java.awt.Dimension(50, 75));
        p_D9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_MotorMouseClicked(evt);
            }
        });
        p_D9.setLayout(new java.awt.BorderLayout());

        D9.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        D9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        D9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/motorIcon.png"))); // NOI18N
        D9.setText("D9");
        D9.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        D9.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        D9.setIconTextGap(10);
        D9.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_D9.add(D9, java.awt.BorderLayout.CENTER);

        p_D10.setBackground(new java.awt.Color(134, 239, 172));
        p_D10.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_D10.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_D10.setName("D10"); // NOI18N
        p_D10.setPreferredSize(new java.awt.Dimension(50, 75));
        p_D10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_MotorMouseClicked(evt);
            }
        });
        p_D10.setLayout(new java.awt.BorderLayout());

        D10.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        D10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        D10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/motorIcon.png"))); // NOI18N
        D10.setText("D10");
        D10.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        D10.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        D10.setIconTextGap(10);
        D10.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_D10.add(D10, java.awt.BorderLayout.CENTER);

        p_D11.setBackground(new java.awt.Color(134, 239, 172));
        p_D11.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_D11.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_D11.setName("D11"); // NOI18N
        p_D11.setPreferredSize(new java.awt.Dimension(50, 75));
        p_D11.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_MotorMouseClicked(evt);
            }
        });
        p_D11.setLayout(new java.awt.BorderLayout());

        D11.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        D11.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        D11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/motorIcon.png"))); // NOI18N
        D11.setText("D11");
        D11.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        D11.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        D11.setIconTextGap(10);
        D11.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_D11.add(D11, java.awt.BorderLayout.CENTER);

        p_D15.setBackground(new java.awt.Color(134, 239, 172));
        p_D15.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_D15.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_D15.setName("D15"); // NOI18N
        p_D15.setPreferredSize(new java.awt.Dimension(50, 75));
        p_D15.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_MotorMouseClicked(evt);
            }
        });
        p_D15.setLayout(new java.awt.BorderLayout());

        D15.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        D15.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        D15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/motorIcon.png"))); // NOI18N
        D15.setText("D15");
        D15.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        D15.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        D15.setIconTextGap(10);
        D15.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_D15.add(D15, java.awt.BorderLayout.CENTER);

        p_D14.setBackground(new java.awt.Color(134, 239, 172));
        p_D14.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_D14.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_D14.setName("D14"); // NOI18N
        p_D14.setPreferredSize(new java.awt.Dimension(50, 75));
        p_D14.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_MotorMouseClicked(evt);
            }
        });
        p_D14.setLayout(new java.awt.BorderLayout());

        D14.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        D14.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        D14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/motorIcon.png"))); // NOI18N
        D14.setText("D14");
        D14.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        D14.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        D14.setIconTextGap(10);
        D14.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_D14.add(D14, java.awt.BorderLayout.CENTER);

        p_D12.setBackground(new java.awt.Color(134, 239, 172));
        p_D12.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_D12.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_D12.setName("D12"); // NOI18N
        p_D12.setPreferredSize(new java.awt.Dimension(50, 75));
        p_D12.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_MotorMouseClicked(evt);
            }
        });
        p_D12.setLayout(new java.awt.BorderLayout());

        D12.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        D12.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        D12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/motorIcon.png"))); // NOI18N
        D12.setText("D12");
        D12.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        D12.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        D12.setIconTextGap(10);
        D12.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_D12.add(D12, java.awt.BorderLayout.CENTER);

        p_D13.setBackground(new java.awt.Color(134, 239, 172));
        p_D13.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_D13.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_D13.setName("D13"); // NOI18N
        p_D13.setPreferredSize(new java.awt.Dimension(50, 75));
        p_D13.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_MotorMouseClicked(evt);
            }
        });
        p_D13.setLayout(new java.awt.BorderLayout());

        D13.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        D13.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        D13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/motorIcon.png"))); // NOI18N
        D13.setText("D13");
        D13.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        D13.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        D13.setIconTextGap(10);
        D13.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_D13.add(D13, java.awt.BorderLayout.CENTER);

        p_PWD1.setBackground(new java.awt.Color(134, 239, 172));
        p_PWD1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_PWD1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_PWD1.setName("PWD1"); // NOI18N
        p_PWD1.setPreferredSize(new java.awt.Dimension(100, 150));
        p_PWD1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_PWDMouseClicked(evt);
            }
        });
        p_PWD1.setLayout(new java.awt.BorderLayout());

        PWD1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        PWD1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        PWD1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/pwdIcon.png"))); // NOI18N
        PWD1.setText("PWD1");
        PWD1.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        PWD1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        PWD1.setIconTextGap(20);
        PWD1.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_PWD1.add(PWD1, java.awt.BorderLayout.CENTER);

        p_PWD2.setBackground(new java.awt.Color(134, 239, 172));
        p_PWD2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_PWD2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_PWD2.setName("PWD2"); // NOI18N
        p_PWD2.setPreferredSize(new java.awt.Dimension(100, 150));
        p_PWD2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_PWDMouseClicked(evt);
            }
        });
        p_PWD2.setLayout(new java.awt.BorderLayout());

        PWD2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        PWD2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        PWD2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/pwdIcon.png"))); // NOI18N
        PWD2.setText("PWD2");
        PWD2.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        PWD2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        PWD2.setIconTextGap(20);
        PWD2.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_PWD2.add(PWD2, java.awt.BorderLayout.CENTER);

        p_PWD3.setBackground(new java.awt.Color(134, 239, 172));
        p_PWD3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_PWD3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_PWD3.setName("PWD3"); // NOI18N
        p_PWD3.setPreferredSize(new java.awt.Dimension(100, 150));
        p_PWD3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_PWDMouseClicked(evt);
            }
        });
        p_PWD3.setLayout(new java.awt.BorderLayout());

        PWD3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        PWD3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        PWD3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/pwdIcon.png"))); // NOI18N
        PWD3.setText("PWD3");
        PWD3.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        PWD3.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        PWD3.setIconTextGap(20);
        PWD3.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_PWD3.add(PWD3, java.awt.BorderLayout.CENTER);

        p_PWD4.setBackground(new java.awt.Color(134, 239, 172));
        p_PWD4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        p_PWD4.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p_PWD4.setName("PWD4"); // NOI18N
        p_PWD4.setPreferredSize(new java.awt.Dimension(100, 150));
        p_PWD4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panel_PWDMouseClicked(evt);
            }
        });
        p_PWD4.setLayout(new java.awt.BorderLayout());

        PWD4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        PWD4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        PWD4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/pwdIcon.png"))); // NOI18N
        PWD4.setText("PWD4");
        PWD4.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        PWD4.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        PWD4.setIconTextGap(20);
        PWD4.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        p_PWD4.add(PWD4, java.awt.BorderLayout.CENTER);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 13, Short.MAX_VALUE)
        );

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 13, Short.MAX_VALUE)
        );

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 13, Short.MAX_VALUE)
        );

        jPanel6.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 13, Short.MAX_VALUE)
        );

        jPanel8.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 13, Short.MAX_VALUE)
        );

        jPanel10.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 13, Short.MAX_VALUE)
        );

        jPanel11.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 13, Short.MAX_VALUE)
        );

        jPanel12.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 13, Short.MAX_VALUE)
        );

        jPanel13.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 13, Short.MAX_VALUE)
        );

        jPanel18.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel18Layout = new javax.swing.GroupLayout(jPanel18);
        jPanel18.setLayout(jPanel18Layout);
        jPanel18Layout.setHorizontalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );
        jPanel18Layout.setVerticalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 13, Short.MAX_VALUE)
        );

        jPanel19.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel19Layout = new javax.swing.GroupLayout(jPanel19);
        jPanel19.setLayout(jPanel19Layout);
        jPanel19Layout.setHorizontalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );
        jPanel19Layout.setVerticalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 13, Short.MAX_VALUE)
        );

        jPanel20.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel20Layout = new javax.swing.GroupLayout(jPanel20);
        jPanel20.setLayout(jPanel20Layout);
        jPanel20Layout.setHorizontalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );
        jPanel20Layout.setVerticalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 13, Short.MAX_VALUE)
        );

        jPanel21.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel21Layout = new javax.swing.GroupLayout(jPanel21);
        jPanel21.setLayout(jPanel21Layout);
        jPanel21Layout.setHorizontalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );
        jPanel21Layout.setVerticalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 13, Short.MAX_VALUE)
        );

        jPanel22.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel22Layout = new javax.swing.GroupLayout(jPanel22);
        jPanel22.setLayout(jPanel22Layout);
        jPanel22Layout.setHorizontalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );
        jPanel22Layout.setVerticalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 13, Short.MAX_VALUE)
        );

        jPanel23.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel23Layout = new javax.swing.GroupLayout(jPanel23);
        jPanel23.setLayout(jPanel23Layout);
        jPanel23Layout.setHorizontalGroup(
            jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );
        jPanel23Layout.setVerticalGroup(
            jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 13, Short.MAX_VALUE)
        );

        jPanel24.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel24Layout = new javax.swing.GroupLayout(jPanel24);
        jPanel24.setLayout(jPanel24Layout);
        jPanel24Layout.setHorizontalGroup(
            jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel24Layout.setVerticalGroup(
            jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 13, Short.MAX_VALUE)
        );

        jPanel32.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel32Layout = new javax.swing.GroupLayout(jPanel32);
        jPanel32.setLayout(jPanel32Layout);
        jPanel32Layout.setHorizontalGroup(
            jPanel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );
        jPanel32Layout.setVerticalGroup(
            jPanel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 13, Short.MAX_VALUE)
        );

        jPanel33.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel33Layout = new javax.swing.GroupLayout(jPanel33);
        jPanel33.setLayout(jPanel33Layout);
        jPanel33Layout.setHorizontalGroup(
            jPanel33Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );
        jPanel33Layout.setVerticalGroup(
            jPanel33Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 13, Short.MAX_VALUE)
        );

        jPanel34.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel34Layout = new javax.swing.GroupLayout(jPanel34);
        jPanel34.setLayout(jPanel34Layout);
        jPanel34Layout.setHorizontalGroup(
            jPanel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );
        jPanel34Layout.setVerticalGroup(
            jPanel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 13, Short.MAX_VALUE)
        );

        jPanel35.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel35Layout = new javax.swing.GroupLayout(jPanel35);
        jPanel35.setLayout(jPanel35Layout);
        jPanel35Layout.setHorizontalGroup(
            jPanel35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );
        jPanel35Layout.setVerticalGroup(
            jPanel35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 13, Short.MAX_VALUE)
        );

        jPanel36.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel36Layout = new javax.swing.GroupLayout(jPanel36);
        jPanel36.setLayout(jPanel36Layout);
        jPanel36Layout.setHorizontalGroup(
            jPanel36Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );
        jPanel36Layout.setVerticalGroup(
            jPanel36Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 13, Short.MAX_VALUE)
        );

        jPanel37.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel37Layout = new javax.swing.GroupLayout(jPanel37);
        jPanel37.setLayout(jPanel37Layout);
        jPanel37Layout.setHorizontalGroup(
            jPanel37Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );
        jPanel37Layout.setVerticalGroup(
            jPanel37Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 13, Short.MAX_VALUE)
        );

        jPanel38.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel38Layout = new javax.swing.GroupLayout(jPanel38);
        jPanel38.setLayout(jPanel38Layout);
        jPanel38Layout.setHorizontalGroup(
            jPanel38Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );
        jPanel38Layout.setVerticalGroup(
            jPanel38Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 13, Short.MAX_VALUE)
        );

        jPanel39.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel39Layout = new javax.swing.GroupLayout(jPanel39);
        jPanel39.setLayout(jPanel39Layout);
        jPanel39Layout.setHorizontalGroup(
            jPanel39Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );
        jPanel39Layout.setVerticalGroup(
            jPanel39Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 13, Short.MAX_VALUE)
        );

        jPanel40.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel40Layout = new javax.swing.GroupLayout(jPanel40);
        jPanel40.setLayout(jPanel40Layout);
        jPanel40Layout.setHorizontalGroup(
            jPanel40Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );
        jPanel40Layout.setVerticalGroup(
            jPanel40Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 13, Short.MAX_VALUE)
        );

        jPanel41.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel41Layout = new javax.swing.GroupLayout(jPanel41);
        jPanel41.setLayout(jPanel41Layout);
        jPanel41Layout.setHorizontalGroup(
            jPanel41Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );
        jPanel41Layout.setVerticalGroup(
            jPanel41Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 13, Short.MAX_VALUE)
        );

        jPanel42.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel42Layout = new javax.swing.GroupLayout(jPanel42);
        jPanel42.setLayout(jPanel42Layout);
        jPanel42Layout.setHorizontalGroup(
            jPanel42Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );
        jPanel42Layout.setVerticalGroup(
            jPanel42Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 13, Short.MAX_VALUE)
        );

        jPanel43.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel43Layout = new javax.swing.GroupLayout(jPanel43);
        jPanel43.setLayout(jPanel43Layout);
        jPanel43Layout.setHorizontalGroup(
            jPanel43Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );
        jPanel43Layout.setVerticalGroup(
            jPanel43Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 13, Short.MAX_VALUE)
        );

        jPanel44.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel44Layout = new javax.swing.GroupLayout(jPanel44);
        jPanel44.setLayout(jPanel44Layout);
        jPanel44Layout.setHorizontalGroup(
            jPanel44Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel44Layout.setVerticalGroup(
            jPanel44Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 13, Short.MAX_VALUE)
        );

        jPanel45.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel45Layout = new javax.swing.GroupLayout(jPanel45);
        jPanel45.setLayout(jPanel45Layout);
        jPanel45Layout.setHorizontalGroup(
            jPanel45Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );
        jPanel45Layout.setVerticalGroup(
            jPanel45Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 13, Short.MAX_VALUE)
        );

        jPanel46.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel46Layout = new javax.swing.GroupLayout(jPanel46);
        jPanel46.setLayout(jPanel46Layout);
        jPanel46Layout.setHorizontalGroup(
            jPanel46Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );
        jPanel46Layout.setVerticalGroup(
            jPanel46Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 13, Short.MAX_VALUE)
        );

        jPanel47.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel47Layout = new javax.swing.GroupLayout(jPanel47);
        jPanel47.setLayout(jPanel47Layout);
        jPanel47Layout.setHorizontalGroup(
            jPanel47Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );
        jPanel47Layout.setVerticalGroup(
            jPanel47Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 13, Short.MAX_VALUE)
        );

        refresh.setBackground(new java.awt.Color(14, 22, 40));
        refresh.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        refresh.setForeground(new java.awt.Color(255, 255, 255));
        refresh.setText("Refresh");
        refresh.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        refresh.addActionListener(this::refreshActionPerformed);

        javax.swing.GroupLayout parkingFloorLayout = new javax.swing.GroupLayout(parkingFloor);
        parkingFloor.setLayout(parkingFloorLayout);
        parkingFloorLayout.setHorizontalGroup(
            parkingFloorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(parkingFloorLayout.createSequentialGroup()
                .addGap(100, 100, 100)
                .addGroup(parkingFloorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(parkingFloorLayout.createSequentialGroup()
                        .addComponent(jPanel32, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel33, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel34, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel37, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel36, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel35, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel38, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel39, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel40, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel41, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel42, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel43, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel47, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel46, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel45, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel44, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(parkingFloorLayout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel18, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel19, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel20, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel23, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel22, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel21, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel24, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(parkingFloorLayout.createSequentialGroup()
                        .addGroup(parkingFloorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(parkingFloorLayout.createSequentialGroup()
                                .addComponent(p_B1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(p_B2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(p_B3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(p_B4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(p_B5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(p_B6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(p_B7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(p_B8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(p_B9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(parkingFloorLayout.createSequentialGroup()
                                .addComponent(p_C1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(p_C2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(p_C3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(p_C4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(p_C5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(p_C6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(p_C7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(p_C8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(p_C9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(parkingFloorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(parkingFloorLayout.createSequentialGroup()
                                .addComponent(p_B10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(p_B11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(parkingFloorLayout.createSequentialGroup()
                                .addComponent(p_C10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(p_C11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(parkingFloorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(p_C12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(p_B12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(parkingFloorLayout.createSequentialGroup()
                        .addGroup(parkingFloorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(p_D1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(p_E1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(parkingFloorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(p_D2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(p_E2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(parkingFloorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(p_D3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(p_E3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(parkingFloorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(p_D4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(p_E4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(parkingFloorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(p_D5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(p_E5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(parkingFloorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(p_D6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(p_E6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(parkingFloorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(p_D7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(p_E7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(parkingFloorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(p_D8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(p_E8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(parkingFloorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(p_D9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(p_E9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(parkingFloorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(p_D10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(p_E10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(parkingFloorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(p_D11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(p_E11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, 0)
                        .addGroup(parkingFloorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(p_E12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(p_D12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(parkingFloorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(p_E13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(p_D13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(parkingFloorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(p_E14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(p_D14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(parkingFloorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(p_E15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(p_D15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(50, 50, 50)
                        .addComponent(p_PWD1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(p_PWD2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(p_PWD3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(p_PWD4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(parkingFloorLayout.createSequentialGroup()
                        .addGroup(parkingFloorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel1)
                            .addGroup(parkingFloorLayout.createSequentialGroup()
                                .addComponent(p_A1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(p_A2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(p_A3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(p_A4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(p_A5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(p_A6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(p_A7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(p_A8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, 0)
                        .addComponent(p_A9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(p_A10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(p_A11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(p_A12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(100, 100, 100)
                .addGroup(parkingFloorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(parkingFloorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jPanel16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jPanel14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(refresh))
                .addContainerGap(101, Short.MAX_VALUE))
        );
        parkingFloorLayout.setVerticalGroup(
            parkingFloorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(parkingFloorLayout.createSequentialGroup()
                .addGap(65, 65, 65)
                .addGroup(parkingFloorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(refresh, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(49, 49, 49)
                .addGroup(parkingFloorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(parkingFloorLayout.createSequentialGroup()
                        .addGroup(parkingFloorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(p_A4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(p_A5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(p_A6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(p_A1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(p_A2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(p_A3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(p_A7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(p_A8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(p_A9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(p_A10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(p_A11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(p_A12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(43, 43, 43)
                        .addGroup(parkingFloorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel18, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel19, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel20, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel23, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel22, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel21, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel24, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(43, 43, 43)
                        .addGroup(parkingFloorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(parkingFloorLayout.createSequentialGroup()
                                .addGroup(parkingFloorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(p_B1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(p_B2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(p_B3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(p_B4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(p_B5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(p_B6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(p_B7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(p_B8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(p_B9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(parkingFloorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(p_C1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(p_C2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(p_C3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(p_C4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(p_C5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(p_C6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(p_C7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(p_C8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(p_C9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(parkingFloorLayout.createSequentialGroup()
                                .addGroup(parkingFloorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(p_B10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(p_B11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(p_B12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addGroup(parkingFloorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(p_C10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(p_C11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(p_C12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(44, 44, 44)
                        .addGroup(parkingFloorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jPanel32, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel33, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel34, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel37, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel36, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel35, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel38, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel39, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel40, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel41, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel42, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel43, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel47, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel46, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel45, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel44, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(43, 43, 43)
                        .addGroup(parkingFloorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(p_PWD1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(p_PWD2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(p_PWD3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(p_PWD4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(parkingFloorLayout.createSequentialGroup()
                                .addComponent(p_D1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(6, 6, 6)
                                .addComponent(p_E1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(parkingFloorLayout.createSequentialGroup()
                                .addComponent(p_D2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(6, 6, 6)
                                .addComponent(p_E2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(parkingFloorLayout.createSequentialGroup()
                                .addComponent(p_D3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(6, 6, 6)
                                .addComponent(p_E3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(parkingFloorLayout.createSequentialGroup()
                                .addComponent(p_D4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(6, 6, 6)
                                .addComponent(p_E4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(parkingFloorLayout.createSequentialGroup()
                                .addComponent(p_D5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(6, 6, 6)
                                .addComponent(p_E5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(parkingFloorLayout.createSequentialGroup()
                                .addComponent(p_D6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(6, 6, 6)
                                .addComponent(p_E6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(parkingFloorLayout.createSequentialGroup()
                                .addComponent(p_D7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(6, 6, 6)
                                .addComponent(p_E7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(parkingFloorLayout.createSequentialGroup()
                                .addComponent(p_D8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(6, 6, 6)
                                .addComponent(p_E8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(parkingFloorLayout.createSequentialGroup()
                                .addComponent(p_D9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(6, 6, 6)
                                .addComponent(p_E9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(parkingFloorLayout.createSequentialGroup()
                                .addComponent(p_D10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(6, 6, 6)
                                .addComponent(p_E10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(parkingFloorLayout.createSequentialGroup()
                                .addComponent(p_D11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(6, 6, 6)
                                .addComponent(p_E11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(parkingFloorLayout.createSequentialGroup()
                                .addComponent(p_D12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(6, 6, 6)
                                .addComponent(p_E12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(parkingFloorLayout.createSequentialGroup()
                                .addComponent(p_D13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(6, 6, 6)
                                .addComponent(p_E13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(parkingFloorLayout.createSequentialGroup()
                                .addComponent(p_D14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(6, 6, 6)
                                .addComponent(p_E14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(parkingFloorLayout.createSequentialGroup()
                                .addComponent(p_D15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(6, 6, 6)
                                .addComponent(p_E15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(parkingFloorLayout.createSequentialGroup()
                        .addComponent(jPanel16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jPanel14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(6, 6, 6)))
                .addContainerGap(135, Short.MAX_VALUE))
        );

        p_A1.getAccessibleContext().setAccessibleName("");
        p_A2.getAccessibleContext().setAccessibleName("");
        p_A3.getAccessibleContext().setAccessibleName("");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(parkingFloor, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 1601, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(parkingFloor, javax.swing.GroupLayout.DEFAULT_SIZE, 1098, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    
    public void parkedSlot(){
        javax.swing.JPanel[] sample = {p_A1, p_A2, p_A3, p_A4, p_A5, p_A6, p_A7, p_A8, p_A9, p_A10, p_A11, p_A12, p_B1, p_B2, p_B3, p_B4, p_B5, p_B6, p_B7, p_B8, p_B9, p_B10, p_B11, p_B12, p_C1, p_C2, p_C3, p_C4, p_C5, p_C6, p_C7, p_C8, p_C9, p_C10, p_C11, p_C12, p_D1, p_D2, p_D3, p_D4, p_D5, p_D6, p_D7, p_D8, p_D9, p_D10, p_D11, p_D12, p_D13, p_D14, p_D15, p_E1, p_E2, p_E3, p_E4, p_E5, p_E6, p_E7, p_E8, p_E9, p_E10, p_E11, p_E12, p_E13, p_E14, p_E15, p_PWD1,p_PWD2,p_PWD3,p_PWD4};
        ParkingController pc = new ParkingController();
        List<Parking> park = pc.select();
        int dumms = 0;
        for(Parking parked: park){
            String parked_status = parked.getStatus();
            if(parked_status.equals("occupied")){
                sample[dumms].setBackground(new java.awt.Color(210, 43, 43)); 
            }else{
                sample[dumms].setBackground(new java.awt.Color(134, 239, 172)); 
            
            }
            dumms++;
        }   
    }
    
    private void panel_CarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panel_CarMouseClicked
        // Find out exactly which panel was clicked
        javax.swing.JPanel clickedPanel = (javax.swing.JPanel) evt.getSource();

        //Get the name of the slot
        String slotName = clickedPanel.getName();
        System.out.println(slotName);

        //Call method
        openParkingDialog(clickedPanel, slotName);
    }//GEN-LAST:event_panel_CarMouseClicked

    private void panel_MotorMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panel_MotorMouseClicked
        javax.swing.JPanel clickedPanel = (javax.swing.JPanel) evt.getSource();

        String slotName = clickedPanel.getName();
        System.out.println(slotName);

        openParkingDialog(clickedPanel, slotName);
    }//GEN-LAST:event_panel_MotorMouseClicked

    private void panel_PWDMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panel_PWDMouseClicked
        javax.swing.JPanel clickedPanel = (javax.swing.JPanel) evt.getSource();

        String slotName = clickedPanel.getName();
        System.out.println(slotName);

        openParkingDialog(clickedPanel, slotName);
    }//GEN-LAST:event_panel_PWDMouseClicked

    private void refreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_refreshActionPerformed
        parkedSlot();
    }//GEN-LAST:event_refreshActionPerformed

    
    private void openParkingDialog(javax.swing.JPanel clickedPanel, String slotName) {
        java.awt.Color currentColor = clickedPanel.getBackground();
        java.awt.Color availableGreen = new java.awt.Color(134, 239, 172);
        
        
        if (currentColor.getRGB() == availableGreen.getRGB()) {
            // GREEN SLOT
            java.awt.Window parentWindow = javax.swing.SwingUtilities.getWindowAncestor(this);
            java.awt.Frame parentFrame = (java.awt.Frame) parentWindow;

            ParkingInputDialog dialog = new ParkingInputDialog(parentFrame, true, slotName);
            dialog.setTargetSlot(clickedPanel);
            dialog.setLocationRelativeTo(this);
            dialog.setVisible(true); 

        } else { 
            // RED SLOT
            Object[] options = {"Check Out", "Relocate", "Clear"};

            int choice = javax.swing.JOptionPane.showOptionDialog(
                this,
                "Slot " + slotName + " is occupied. What would you like to do?",
                "Manage Occupied Slot",
                javax.swing.JOptionPane.DEFAULT_OPTION,
                javax.swing.JOptionPane.QUESTION_MESSAGE,
                null, 
                options,
                options[0] 
            );

            // button clicks
            if (choice == 0) {
                // ASK FOR PAYMENT
                ParkingController pc = new ParkingController();

                pc.checkout(slotName); //STARTS CHECKOUT
                
                String[] mainDetails = pc.getMainData(slotName);

                double extra_price=0.0;
                double prices = Double.parseDouble(mainDetails[3]);
                

                
                int gap = pc.day_check(slotName); //RETURNS DAY GAP
                
                if(gap != 0){ //If theres a day gap
                    extra_price = (gap * 300);
                    prices = Double.parseDouble(mainDetails[3]) + extra_price;
                    pc.extra(slotName,  extra_price, prices);
                    
                }

                
                
                String paymentStr = javax.swing.JOptionPane.showInputDialog(
                        this, 
                        "Total Price: "+prices+"\nEnter customer payment amount:", 
                        "Process Payment", 
                        javax.swing.JOptionPane.QUESTION_MESSAGE
                );
                
                // CANCELATION
                if (paymentStr == null) {
                    System.out.println("Cashier canceled the checkout.");
                    return;
                }
                
                double payment = Integer.parseInt(paymentStr);
                
                // 3. PROCEED WITH CHECKOUT
                System.out.println("Checkout clicked for " + slotName);
                
                
                if(payment >= prices){ //FOR PAYMENT LOGIC
                    //Wipes data on the table
                    double keep_change = payment - prices; //Change for receipt only
                    pc.pay(slotName, payment, keep_change);
                    pc.transfer(slotName);
                    pc.reset(slotName);
                    clickedPanel.setBackground(availableGreen);
                    clickedPanel.revalidate();
                    clickedPanel.repaint();
                    System.out.println("Slot " + slotName + " has been checked out.");
                    javax.swing.JOptionPane.showMessageDialog(this, "Payment Success.");
                    

                }else{
                    JOptionPane.showMessageDialog(this, "Insufficient Amount!", "Payment Error!", JOptionPane.ERROR_MESSAGE);
                }
              
                String[] receiptDetails = pc.getReceiptData(slotName);

                
                // OPEN RECEIPT
                if (receiptDetails != null && receiptDetails[0] != null && payment >= prices) {
                    java.awt.Window parentWindow = javax.swing.SwingUtilities.getWindowAncestor(this);
                    java.awt.Frame parentFrame = (java.awt.Frame) parentWindow;
                    
                    ReceiptDialog receipt = new ReceiptDialog(parentFrame, true);

                    receipt.setReceiptData(receiptDetails[0], receiptDetails[1], receiptDetails[2], receiptDetails[3] , receiptDetails[4], receiptDetails[5],receiptDetails[6]);

                    receipt.setLocationRelativeTo(this);
                    receipt.setVisible(true); 
                }

                
            } else if (choice == 1) {
                // Relocate
                System.out.println("Relocate clicked for " + slotName);
                
                // Input Dialog for relocate
                String newSlotStr = javax.swing.JOptionPane.showInputDialog(
                        this, 
                        "Enter the new slot to relocate the vehicle from " + slotName + " :", 
                        "Relocate Vehicle", 
                        javax.swing.JOptionPane.QUESTION_MESSAGE                         
                        
                );
                
                // Check if they typed something
                if (newSlotStr != null && !newSlotStr.trim().isEmpty()) {
                    
                    ParkingController pc = new ParkingController();
                    
                    String[] vehicle_eval = pc.getMainData(slotName);
                    boolean vehicle_check = false;
                    
                    String vehicle = vehicle_eval[6];
                    String slot_char = newSlotStr.substring(0,1);
                    System.out.println("slot char: "+slot_char);
                    
                    if(slot_char.equals("A") || slot_char.equals("B") || slot_char.equals("C")){
                        if(vehicle.equals("Sedan") || vehicle.equals("SUV") || vehicle.equals("Truck") || vehicle.equals("Electric Vehicle") || vehicle.equals("Others")){
                            vehicle_check = true;
                        }
                    }else if(slot_char.equals("D")|| slot_char.equals("E")){
                        if(vehicle.equals("Motorcycle") || vehicle.equals("Others")){
                            vehicle_check = true;
                        }
                    }else if(slot_char.equals("P")){
                        vehicle_check = true;
                    }
                    
                    

                    
                    // Automatically uppercase
                    String targetSlot = newSlotStr.trim().toUpperCase(); 
                    
                    // relocate logic here
                    
                    String[] slots = {
                        "A1", "A2", "A3", "A4", "A5", "A6", "A7", "A8", "A9", "A10", "A11", "A12",
                        "B1", "B2", "B3", "B4", "B5", "B6", "B7", "B8", "B9", "B10", "B11", "B12",
                        "C1", "C2", "C3", "C4", "C5", "C6", "C7", "C8", "C9", "C10", "C11", "C12",
                        "D1", "D2", "D3", "D4", "D5", "D6", "D7", "D8", "D9", "D10", "D11", "D12", "D13", "D14", "D15",
                        "E1", "E2", "E3", "E4", "E5", "E6", "E7", "E8", "E9", "E10", "E11", "E12", "E13", "E14", "E15",
                        "PWD1", "PWD2", "PWD3", "PWD4"
                    };
                    
                    boolean checker = false;
                    for(String slot: slots){ //Checks if the inserted value is one of the spots
                        if(newSlotStr.equals((slot))){
                            checker = true;
                        }
                    }

                    //ParkingController pc = new ParkingController();
                    
                    if(checker){
                        if(vehicle_check){
                            if(pc.verify_slot(newSlotStr)){
                                pc.relocate(slotName, newSlotStr);
                                pc.reset(slotName);
                                javax.swing.JOptionPane.showMessageDialog(this, "Relocation Successful.");

                            }else{
                                JOptionPane.showMessageDialog(this, "Slot is Already Occupied!", "Relocation Error!", JOptionPane.ERROR_MESSAGE);
                            }  
                        }else{
                            JOptionPane.showMessageDialog(this, "Cannot Park "+vehicle+" Into Slot "+newSlotStr+"!", "Relocation Error!", JOptionPane.ERROR_MESSAGE);
                        }
                    }else{
                        JOptionPane.showMessageDialog(this, "Invalid Inserted Spot!", "Relocation Error!", JOptionPane.ERROR_MESSAGE);
                    }
                }
                
            } else if (choice == 2) {
                // CLEAR
                int confirmClear = javax.swing.JOptionPane.showConfirmDialog(
                    this,
                    "Are you sure you want to forcibly clear Slot " + slotName + "?\nThis will remove the vehicle without a receipt or log.",
                    "Confirm Clear Slot",
                    javax.swing.JOptionPane.YES_NO_OPTION,
                    javax.swing.JOptionPane.WARNING_MESSAGE 
                );

                if (confirmClear == javax.swing.JOptionPane.YES_OPTION) {
                    //Wipe the database
                    ParkingController pc = new ParkingController();
                    pc.reset(slotName); 
                    
                    //Turn the slot back to green
                    clickedPanel.setBackground(availableGreen);
                    clickedPanel.revalidate();
                    clickedPanel.repaint();
                    System.out.println("Slot " + slotName + " has been forcefully cleared.");
                }
            }
        }
}

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel A1;
    private javax.swing.JLabel A10;
    private javax.swing.JLabel A11;
    private javax.swing.JLabel A12;
    private javax.swing.JLabel A2;
    private javax.swing.JLabel A3;
    private javax.swing.JLabel A4;
    private javax.swing.JLabel A5;
    private javax.swing.JLabel A6;
    private javax.swing.JLabel A7;
    private javax.swing.JLabel A8;
    private javax.swing.JLabel A9;
    private javax.swing.JLabel B1;
    private javax.swing.JLabel B10;
    private javax.swing.JLabel B11;
    private javax.swing.JLabel B12;
    private javax.swing.JLabel B2;
    private javax.swing.JLabel B3;
    private javax.swing.JLabel B4;
    private javax.swing.JLabel B5;
    private javax.swing.JLabel B6;
    private javax.swing.JLabel B7;
    private javax.swing.JLabel B8;
    private javax.swing.JLabel B9;
    private javax.swing.JLabel C1;
    private javax.swing.JLabel C10;
    private javax.swing.JLabel C11;
    private javax.swing.JLabel C12;
    private javax.swing.JLabel C2;
    private javax.swing.JLabel C3;
    private javax.swing.JLabel C4;
    private javax.swing.JLabel C5;
    private javax.swing.JLabel C6;
    private javax.swing.JLabel C7;
    private javax.swing.JLabel C8;
    private javax.swing.JLabel C9;
    private javax.swing.JLabel D1;
    private javax.swing.JLabel D10;
    private javax.swing.JLabel D11;
    private javax.swing.JLabel D12;
    private javax.swing.JLabel D13;
    private javax.swing.JLabel D14;
    private javax.swing.JLabel D15;
    private javax.swing.JLabel D2;
    private javax.swing.JLabel D3;
    private javax.swing.JLabel D4;
    private javax.swing.JLabel D5;
    private javax.swing.JLabel D6;
    private javax.swing.JLabel D7;
    private javax.swing.JLabel D8;
    private javax.swing.JLabel D9;
    private javax.swing.JLabel E1;
    private javax.swing.JLabel E10;
    private javax.swing.JLabel E11;
    private javax.swing.JLabel E13;
    private javax.swing.JLabel E14;
    private javax.swing.JLabel E15;
    private javax.swing.JLabel E2;
    private javax.swing.JLabel E3;
    private javax.swing.JLabel E4;
    private javax.swing.JLabel E5;
    private javax.swing.JLabel E6;
    private javax.swing.JLabel E7;
    private javax.swing.JLabel E8;
    private javax.swing.JLabel E9;
    private javax.swing.JLabel PWD1;
    private javax.swing.JLabel PWD2;
    private javax.swing.JLabel PWD3;
    private javax.swing.JLabel PWD4;
    private javax.swing.JLabel dumm;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel22;
    private javax.swing.JPanel jPanel23;
    private javax.swing.JPanel jPanel24;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel32;
    private javax.swing.JPanel jPanel33;
    private javax.swing.JPanel jPanel34;
    private javax.swing.JPanel jPanel35;
    private javax.swing.JPanel jPanel36;
    private javax.swing.JPanel jPanel37;
    private javax.swing.JPanel jPanel38;
    private javax.swing.JPanel jPanel39;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel40;
    private javax.swing.JPanel jPanel41;
    private javax.swing.JPanel jPanel42;
    private javax.swing.JPanel jPanel43;
    private javax.swing.JPanel jPanel44;
    private javax.swing.JPanel jPanel45;
    private javax.swing.JPanel jPanel46;
    private javax.swing.JPanel jPanel47;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JPanel p_A1;
    private javax.swing.JPanel p_A10;
    private javax.swing.JPanel p_A11;
    private javax.swing.JPanel p_A12;
    private javax.swing.JPanel p_A2;
    private javax.swing.JPanel p_A3;
    private javax.swing.JPanel p_A4;
    private javax.swing.JPanel p_A5;
    private javax.swing.JPanel p_A6;
    private javax.swing.JPanel p_A7;
    private javax.swing.JPanel p_A8;
    private javax.swing.JPanel p_A9;
    private javax.swing.JPanel p_B1;
    private javax.swing.JPanel p_B10;
    private javax.swing.JPanel p_B11;
    private javax.swing.JPanel p_B12;
    private javax.swing.JPanel p_B2;
    private javax.swing.JPanel p_B3;
    private javax.swing.JPanel p_B4;
    private javax.swing.JPanel p_B5;
    private javax.swing.JPanel p_B6;
    private javax.swing.JPanel p_B7;
    private javax.swing.JPanel p_B8;
    private javax.swing.JPanel p_B9;
    private javax.swing.JPanel p_C1;
    private javax.swing.JPanel p_C10;
    private javax.swing.JPanel p_C11;
    private javax.swing.JPanel p_C12;
    private javax.swing.JPanel p_C2;
    private javax.swing.JPanel p_C3;
    private javax.swing.JPanel p_C4;
    private javax.swing.JPanel p_C5;
    private javax.swing.JPanel p_C6;
    private javax.swing.JPanel p_C7;
    private javax.swing.JPanel p_C8;
    private javax.swing.JPanel p_C9;
    private javax.swing.JPanel p_D1;
    private javax.swing.JPanel p_D10;
    private javax.swing.JPanel p_D11;
    private javax.swing.JPanel p_D12;
    private javax.swing.JPanel p_D13;
    private javax.swing.JPanel p_D14;
    private javax.swing.JPanel p_D15;
    private javax.swing.JPanel p_D2;
    private javax.swing.JPanel p_D3;
    private javax.swing.JPanel p_D4;
    private javax.swing.JPanel p_D5;
    private javax.swing.JPanel p_D6;
    private javax.swing.JPanel p_D7;
    private javax.swing.JPanel p_D8;
    private javax.swing.JPanel p_D9;
    private javax.swing.JPanel p_E1;
    private javax.swing.JPanel p_E10;
    private javax.swing.JPanel p_E11;
    private javax.swing.JPanel p_E12;
    private javax.swing.JPanel p_E13;
    private javax.swing.JPanel p_E14;
    private javax.swing.JPanel p_E15;
    private javax.swing.JPanel p_E2;
    private javax.swing.JPanel p_E3;
    private javax.swing.JPanel p_E4;
    private javax.swing.JPanel p_E5;
    private javax.swing.JPanel p_E6;
    private javax.swing.JPanel p_E7;
    private javax.swing.JPanel p_E8;
    private javax.swing.JPanel p_E9;
    private javax.swing.JPanel p_PWD1;
    private javax.swing.JPanel p_PWD2;
    private javax.swing.JPanel p_PWD3;
    private javax.swing.JPanel p_PWD4;
    private javax.swing.JPanel parkingFloor;
    private javax.swing.JButton refresh;
    // End of variables declaration//GEN-END:variables
}
