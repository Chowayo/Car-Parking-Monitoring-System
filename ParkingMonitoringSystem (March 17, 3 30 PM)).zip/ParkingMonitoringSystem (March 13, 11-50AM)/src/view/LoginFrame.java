package view;
import Controllers.UserController;
import Models.Users;
import java.util.List;
import java.util.prefs.Preferences;
import javax.swing.JOptionPane;


public class LoginFrame extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(LoginFrame.class.getName());

    public static String employeeID, firstname, lastname, email, password;
    public static int id;
    public LoginFrame() {
        
    initComponents();
    
    this.setLocationRelativeTo(null);
    
        loginEmployeeID.setText("Employee ID");
        loginEmployeeID.setForeground(new java.awt.Color(153, 153, 153)); // Grey hint color
        
        jPanel1.setFocusable(true); 
        
        javax.swing.SwingUtilities.invokeLater(() -> {
            jPanel1.requestFocusInWindow();
        });
        
    loginPassword.setText("Password");
    loginPassword.setEchoChar((char) 0);
    loginPassword.setForeground(new java.awt.Color(153, 153, 153));
        
        
    javax.swing.ImageIcon originalIcon = new javax.swing.ImageIcon(getClass().getResource("/view/Images/usernameIcon.png"));

    if (originalIcon != null) {
        java.awt.Image image = originalIcon.getImage();
        java.awt.Image newimg = image.getScaledInstance(35, 35, java.awt.Image.SCALE_SMOOTH);

        // Put it on the NEW label
        lblUserIcon.setIcon(new javax.swing.ImageIcon(newimg));
    }
    javax.swing.ImageIcon lockOriginal = new javax.swing.ImageIcon(getClass().getResource("/view/Images/lockIcon.png"));

    if (lockOriginal != null) {
        java.awt.Image lockImg = lockOriginal.getImage();
        java.awt.Image lockScaled = lockImg.getScaledInstance(35, 35, java.awt.Image.SCALE_SMOOTH);

        //new label
        lblPassIcon.setIcon(new javax.swing.ImageIcon(lockScaled));
    }

    Preferences prefs = Preferences.userNodeForPackage(LoginFrame.class);

            // Check if "Remember Me" was checked last time
            if (prefs.getBoolean("rememberMe", false)) {

                //Get the saved text
                String savedID = prefs.get("savedUsername", "");
                String savedPass = prefs.get("savedPassword", "");

                // Put it in the boxes
                loginEmployeeID.setText(savedID);
                loginPassword.setText(savedPass);
                rememberMe.setSelected(true);

                loginEmployeeID.setForeground(new java.awt.Color(0, 0, 0)); // Black Text
                loginPassword.setForeground(new java.awt.Color(0, 0, 0));   // Black Text
                loginPassword.setEchoChar('*'); //security dots
            }

        }
    
      
    public LoginFrame(String employeeID,String first_name, String last_name , String email, String password, int id) {
        this();
        this.employeeID = employeeID;
        this.firstname = first_name;
        this.lastname = last_name;
        this.email = email;
        this.password = password;
        this.id = id;
    }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        loginEmployeeID = new javax.swing.JTextField();
        loginPassword = new javax.swing.JPasswordField();
        signInBtn = new javax.swing.JButton();
        rememberMe = new javax.swing.JCheckBox();
        forgotPassBtn = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        lblUserIcon = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        lblPassIcon = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        role = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(14, 22, 40));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Login");

        loginEmployeeID.setForeground(new java.awt.Color(14, 22, 40));
        loginEmployeeID.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        loginEmployeeID.setMargin(new java.awt.Insets(2, 110, 2, 6));
        loginEmployeeID.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                loginEmployeeIDFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                loginEmployeeIDFocusLost(evt);
            }
        });

        loginPassword.setForeground(new java.awt.Color(14, 22, 40));
        loginPassword.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        loginPassword.setMargin(new java.awt.Insets(2, 100, 2, 6));
        loginPassword.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                loginPasswordFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                loginPasswordFocusLost(evt);
            }
        });

        signInBtn.setBackground(new java.awt.Color(255, 81, 0));
        signInBtn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        signInBtn.setForeground(new java.awt.Color(255, 255, 255));
        signInBtn.setText("Sign In");
        signInBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        signInBtn.addActionListener(this::signInBtnActionPerformed);

        rememberMe.setBackground(new java.awt.Color(14, 22, 40));
        rememberMe.setForeground(new java.awt.Color(157, 165, 177));
        rememberMe.setText("Remember me");
        rememberMe.addActionListener(this::rememberMeActionPerformed);

        forgotPassBtn.setForeground(new java.awt.Color(157, 165, 177));
        forgotPassBtn.setText("<html><u>Forgot password?</u></html>");
        forgotPassBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        forgotPassBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                forgotPassBtnMouseClicked(evt);
            }
        });

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setOpaque(false);
        jPanel2.setLayout(new java.awt.BorderLayout());

        lblUserIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/usernameIcon.png"))); // NOI18N
        jPanel2.add(lblUserIcon, java.awt.BorderLayout.PAGE_END);

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));
        jPanel4.setOpaque(false);
        jPanel4.setLayout(new java.awt.BorderLayout());

        lblPassIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/lockIcon.png"))); // NOI18N
        jPanel4.add(lblPassIcon, java.awt.BorderLayout.CENTER);

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/Images/641115070_960940203026398_8345294270381116164_n (1).png"))); // NOI18N

        role.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Operator", "Admin" }));
        role.addActionListener(this::roleActionPerformed);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(120, 120, 120)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(87, 87, 87)
                        .addComponent(jLabel1))
                    .addComponent(role, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(loginEmployeeID)
                    .addComponent(loginPassword)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(rememberMe)
                        .addGap(91, 91, 91)
                        .addComponent(forgotPassBtn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(signInBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(120, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(269, 269, 269)
                .addComponent(jLabel3)
                .addContainerGap(258, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(45, 45, 45)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(loginEmployeeID, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(loginPassword, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(39, 39, 39))
                    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addComponent(role, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(rememberMe)
                    .addComponent(forgotPassBtn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(signInBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(79, 79, 79))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void forgotPassBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_forgotPassBtnMouseClicked
        ForgotPassFrame resetFrame = new ForgotPassFrame();
        resetFrame.setVisible(true);

        this.dispose();
    }//GEN-LAST:event_forgotPassBtnMouseClicked

    
    //SPACER
    private void signInBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_signInBtnActionPerformed
       
    String employeeId = loginEmployeeID.getText();
    String passw = loginPassword.getText();
    String roles = role.getSelectedItem().toString();
    UserController usercon = new UserController();
    
    String DB_table="";
    if(roles.equals("Admin")){
        DB_table = "admin";

    }else if(roles.equals("Operator")){
        DB_table = "employees";
    } 
    
    
    
    
    String password_convert = usercon.encryptPassword(loginPassword.getText());
        
        if(!employeeId.trim().isEmpty() && !passw.trim().isEmpty()){
            
            try {
                int int_id = Integer.parseInt(employeeId); // Convert ID to integer safely

                if(usercon.authenticate(employeeId, password_convert, DB_table) != null){ 
                    
                    // Session Logic
                    List<Users> session = usercon.session(int_id, password_convert, DB_table);
                    for(Users user: session){
                        this.firstname = user.getFname();
                        this.lastname = user.getLname();
                        this.email = user.getEmail();
                        this.password = user.getPassword();
                        this.id = user.getId();
                        this.employeeID = user.getEmployeeID();
                    }
                    
                    JOptionPane.showMessageDialog(this, "Login Successful"); 
                    
                    //MICHAEL NOTE: Hindi pa sure kung nagana to CHOW: NAGANA NA
                    Preferences prefs = Preferences.userNodeForPackage(LoginFrame.class);
                    if (rememberMe.isSelected()) {
                        // Save the username and password
                        prefs.put("savedUsername", employeeId);
                        prefs.put("savedPassword", passw); 
                        prefs.putBoolean("rememberMe", true);
                    } else {
                        // If unchecked, remove the saved data
                        prefs.remove("savedUsername");
                        prefs.remove("savedPassword");
                        prefs.remove("rememberMe");
                    }
                    
                    String loggedInId = loginEmployeeID.getText();

                    // Proceed to Dashboard
                    if(roles.equals("Admin")){
                        AdminDashboardFrame adf = new AdminDashboardFrame(employeeId);
                        adf.setVisible(true);
                    }else if(roles.equals("Operator")){
                        DashboardFrameMain df = new DashboardFrameMain(employeeId); 
                        df.setVisible(true);
                    } 
                    this.dispose();
                
                } else {
                    JOptionPane.showMessageDialog(this, "Invalid EmployeeID or Password", "Error", JOptionPane.ERROR_MESSAGE); //Acts as a sweet alert for error
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Employee ID must be a number", "Error", JOptionPane.ERROR_MESSAGE);
            }

        } else {
            JOptionPane.showMessageDialog(this, "Textbox empty!", "Error", JOptionPane.ERROR_MESSAGE); //Acts as a sweet alert for error
        }
        
        
        
           
    }//GEN-LAST:event_signInBtnActionPerformed

    private void loginEmployeeIDFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_loginEmployeeIDFocusGained
        // TODO add your handling code here:
        
        if (loginEmployeeID.getText().equals("Employee ID")) {
        loginEmployeeID.setText("");
        loginEmployeeID.setForeground(new java.awt.Color(0, 0, 0)); // Set text color to Black for typing
        }
        
    }//GEN-LAST:event_loginEmployeeIDFocusGained

    private void loginEmployeeIDFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_loginEmployeeIDFocusLost
        // TODO add your handling code here:
        if (loginEmployeeID.getText().isEmpty()) {
            loginEmployeeID.setText("Employee ID");
            loginEmployeeID.setForeground(new java.awt.Color(153, 153, 153));
            }
    }//GEN-LAST:event_loginEmployeeIDFocusLost

    
    private void loginPasswordFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_loginPasswordFocusGained
        // TODO add your handling code here:
        String pass = new String(loginPassword.getPassword());
    
        if (pass.equals("Password")) {
            loginPassword.setText("");
            loginPassword.setForeground(new java.awt.Color(0, 0, 0));
            loginPassword.setEchoChar('*'); //dots security
        }
    }//GEN-LAST:event_loginPasswordFocusGained

    private void loginPasswordFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_loginPasswordFocusLost
        // TODO add your handling code here:
        String pass = new String(loginPassword.getPassword());
    
        if (pass.isEmpty()) {
            loginPassword.setText("Password");
            loginPassword.setForeground(new java.awt.Color(153, 153, 153));
            loginPassword.setEchoChar((char) 0); // Turn OFF dots security so user can read Password
        }
    }//GEN-LAST:event_loginPasswordFocusLost

    private void rememberMeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rememberMeActionPerformed
        // TODO add your handling code here:
            // Check the box UNCHECKED
        if (!rememberMe.isSelected()) {

            // Delete the saved file immediately
            Preferences prefs = Preferences.userNodeForPackage(LoginFrame.class);
            prefs.remove("savedUsername");
            prefs.remove("savedPassword");
            prefs.remove("rememberMe");

            // Clear the text boxes on the screen
            loginEmployeeID.setText("Employee ID");
            loginEmployeeID.setForeground(new java.awt.Color(153, 153, 153));

            loginPassword.setText("Password");
            loginPassword.setEchoChar((char) 0); // Show text
            loginPassword.setForeground(new java.awt.Color(153, 153, 153));
        }
    }//GEN-LAST:event_rememberMeActionPerformed

    private void roleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_roleActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_roleActionPerformed

    
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> {
        // MAKE SURE THIS SAYS LoginFrame, NOT DashboardFrameMain
        new LoginFrame().setVisible(true); 
    });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel forgotPassBtn;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JLabel lblPassIcon;
    private javax.swing.JLabel lblUserIcon;
    private javax.swing.JTextField loginEmployeeID;
    private javax.swing.JPasswordField loginPassword;
    private javax.swing.JCheckBox rememberMe;
    private javax.swing.JComboBox<String> role;
    private javax.swing.JButton signInBtn;
    // End of variables declaration//GEN-END:variables
}
